# Règles R8/ProGuard spécifiques à FileMaster (vide pour l'instant).
