package com.filemaster.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Graphique en anneau : chaque tranche = (couleur, valeur). Le contenu est centré dans l'anneau. */
@Composable
fun DonutChart(
    slices: List<Pair<Color, Float>>,
    trackColor: Color,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 26.dp,
    center: @Composable BoxScope.() -> Unit = {}
) {
    val total = slices.sumOf { it.second.toDouble() }.toFloat()
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = strokeWidth.toPx()
            val inset = stroke / 2
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(inset, inset)
            drawArc(trackColor, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
            if (total > 0f) {
                var start = -90f
                for ((color, value) in slices) {
                    val sweep = value / total * 360f
                    if (sweep > 0.5f) {
                        drawArc(color, start, (sweep - 1.5f).coerceAtLeast(0.5f), false, topLeft, arcSize, style = Stroke(stroke))
                    }
                    start += sweep
                }
            }
        }
        center()
    }
}
