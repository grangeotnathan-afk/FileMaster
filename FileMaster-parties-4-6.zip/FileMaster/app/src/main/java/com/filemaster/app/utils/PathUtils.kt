package com.filemaster.app.utils

data class Crumb(val label: String, val path: String)

/** Construit le fil d'Ariane d'un chemin, relatif à la racine du stockage interne si possible. */
fun buildCrumbs(path: String, root: String): List<Crumb> {
    val crumbs = mutableListOf<Crumb>()
    if (path == root || path.startsWith("$root/")) {
        crumbs += Crumb("Stockage interne", root)
        var acc = root
        path.removePrefix(root).split('/').filter { it.isNotEmpty() }.forEach {
            acc = "$acc/$it"
            crumbs += Crumb(it, acc)
        }
    } else {
        crumbs += Crumb("/", "/")
        var acc = ""
        path.split('/').filter { it.isNotEmpty() }.forEach {
            acc = "$acc/$it"
            crumbs += Crumb(it, acc)
        }
    }
    return crumbs
}
