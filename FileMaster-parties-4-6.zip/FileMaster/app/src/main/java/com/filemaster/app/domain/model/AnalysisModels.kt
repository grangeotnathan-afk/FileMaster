package com.filemaster.app.domain.model

data class CategoryStat(val category: FileCategory, val count: Int, val size: Long)

data class FolderStat(val path: String, val size: Long)

data class JunkItem(val file: FileItem, val reason: String)

data class DuplicateGroup(val size: Long, val hash: String, val files: List<FileItem>) {
    /** Espace récupérable en ne gardant qu'une copie. */
    val wasted: Long get() = size * (files.size - 1)
}

data class AnalysisResult(
    val totalSize: Long,
    val fileCount: Int,
    val categories: List<CategoryStat>,
    val largest: List<FileItem>,
    val folders: List<FolderStat>,
    val junk: List<JunkItem>
)
