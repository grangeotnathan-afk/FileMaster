package com.filemaster.app.domain.model

data class FileItem(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long,
    val extension: String,
    val category: FileCategory,
    val childCount: Int?,
    val isHidden: Boolean
)
