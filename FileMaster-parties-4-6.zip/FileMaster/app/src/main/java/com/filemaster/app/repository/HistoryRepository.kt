package com.filemaster.app.repository

import com.filemaster.app.database.OperationDao
import com.filemaster.app.database.OperationEntity
import com.filemaster.app.domain.model.OperationRecord
import com.filemaster.app.domain.model.OperationType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Historique des opérations réellement effectuées par l'application. */
class HistoryRepository(private val dao: OperationDao) {

    fun observeRecent(limit: Int): Flow<List<OperationRecord>> = dao.observeRecent(limit).map { list ->
        list.map { OperationRecord(OperationType.fromName(it.type), it.description, it.success, it.timestamp) }
    }

    suspend fun log(type: OperationType, description: String, success: Boolean) {
        dao.insert(OperationEntity(type = type.name, description = description, success = success, timestamp = System.currentTimeMillis()))
        dao.trim(500)
    }

    suspend fun clear() = dao.clear()
}
