package com.filemaster.app.data

import android.content.Context
import androidx.room.Room
import com.filemaster.app.data.settings.SettingsRepository
import com.filemaster.app.database.AppDatabase
import com.filemaster.app.database.MIGRATION_1_2
import com.filemaster.app.repository.DuplicateFinder
import com.filemaster.app.repository.FavoritesRepository
import com.filemaster.app.repository.FileRepository
import com.filemaster.app.repository.HistoryRepository
import com.filemaster.app.repository.RecentRepository
import com.filemaster.app.repository.ScanRepository
import com.filemaster.app.repository.StorageRepository
import com.filemaster.app.services.DownloadCoordinator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Injection de dépendances manuelle (simple, sans bibliothèque supplémentaire). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    /** Scope lié à la vie du processus (parcours du stockage, téléchargements). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase by lazy {
        Room.databaseBuilder(appContext, AppDatabase::class.java, "filemaster.db")
            .addMigrations(MIGRATION_1_2)
            .build()
    }

    val settingsRepository = SettingsRepository(appContext)
    val storageRepository = StorageRepository()
    val fileRepository = FileRepository()
    val duplicateFinder = DuplicateFinder()
    val scanRepository = ScanRepository(appScope)
    val favoritesRepository: FavoritesRepository by lazy { FavoritesRepository(database.favoriteDao()) }
    val recentRepository: RecentRepository by lazy { RecentRepository(database.recentDao()) }
    val historyRepository: HistoryRepository by lazy { HistoryRepository(database.operationDao()) }
    val downloadCoordinator: DownloadCoordinator by lazy {
        DownloadCoordinator(appContext, database.downloadDao(), historyRepository, appScope)
    }
}
