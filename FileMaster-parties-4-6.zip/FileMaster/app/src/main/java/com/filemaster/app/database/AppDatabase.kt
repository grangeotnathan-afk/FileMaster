package com.filemaster.app.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [FavoriteEntity::class, RecentFileEntity::class, OperationEntity::class, DownloadEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun recentDao(): RecentDao
    abstract fun operationDao(): OperationDao
    abstract fun downloadDao(): DownloadDao
}

/** v1 -> v2 : ajout de la table des téléchargements (les favoris et l'historique sont conservés). */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `downloads` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`url` TEXT NOT NULL, `fileName` TEXT NOT NULL, `destDir` TEXT NOT NULL, " +
                "`totalBytes` INTEGER NOT NULL, `downloadedBytes` INTEGER NOT NULL, " +
                "`status` TEXT NOT NULL, `error` TEXT, `acceptsRanges` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, `finishedAt` INTEGER)"
        )
    }
}
