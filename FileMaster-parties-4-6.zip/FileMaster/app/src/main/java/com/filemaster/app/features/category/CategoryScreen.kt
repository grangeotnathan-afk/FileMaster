package com.filemaster.app.features.category

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemaster.app.domain.model.ScanStatus
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.ui.components.FileRow
import com.filemaster.app.utils.FileActions
import com.filemaster.app.utils.elementsLabel
import com.filemaster.app.utils.formatDate
import com.filemaster.app.utils.formatSize
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryScreen(
    onBack: () -> Unit,
    onOpenFolder: (String) -> Unit,
    viewModel: CategoryViewModel = viewModel(factory = CategoryViewModel.Factory)
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val category = viewModel.category

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                title = { Text(category.title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour") }
                },
                actions = {
                    if (category != SmartCategory.FAVORITES) {
                        IconButton(onClick = { viewModel.rescan() }, enabled = state.status != ScanStatus.RUNNING) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Relancer l'analyse")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when {
                state.status == ScanStatus.RUNNING -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(16.dp))
                    Text("Parcours du stockage… ${state.filesFound} fichiers trouvés", textAlign = TextAlign.Center)
                }
                state.status == ScanStatus.IDLE -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        "Le stockage n'a pas pu être parcouru. Vérifiez que l'accès aux fichiers est accordé.",
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { viewModel.rescan() }) { Text("Réessayer") }
                }
                else -> {
                    val info = buildString {
                        append(elementsLabel(state.items.size))
                        if (state.items.any { !it.isDirectory }) append(" • ${formatSize(state.totalSize)}")
                        state.finishedAt?.let { append(" • analysé le ${formatDate(it)}") }
                    }
                    Text(
                        info,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    if (state.items.isEmpty()) {
                        Text(
                            "Aucun fichier dans cette catégorie.",
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            "Appui long : afficher dans son dossier",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        LazyColumn(contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            items(state.items, key = { it.path }) { item ->
                                FileRow(
                                    item = item,
                                    showExtension = state.settings.showExtensions,
                                    itemSize = state.settings.itemSize,
                                    extraLine = File(item.path).parent?.substringAfterLast('/'),
                                    onClick = {
                                        if (item.isDirectory) {
                                            onOpenFolder(item.path)
                                        } else {
                                            viewModel.onFileOpened(item.path)
                                            FileActions.open(context, File(item.path))
                                        }
                                    },
                                    onLongClick = { onOpenFolder(File(item.path).parent ?: item.path) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
