package com.filemaster.app.domain.model

enum class FileCategory(val label: String) {
    IMAGES("Images"),
    VIDEOS("Vidéos"),
    AUDIO("Musique"),
    DOCUMENTS("Documents"),
    APK("APK"),
    ARCHIVES("Archives"),
    OTHER("Autres");

    companion object {
        private val byExtension: Map<String, FileCategory> = buildMap {
            listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg").forEach { put(it, IMAGES) }
            listOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v").forEach { put(it, VIDEOS) }
            listOf("mp3", "wav", "flac", "aac", "ogg", "m4a", "opus", "wma", "amr").forEach { put(it, AUDIO) }
            listOf(
                "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "rtf",
                "odt", "ods", "odp", "csv", "json", "xml", "html", "log"
            ).forEach { put(it, DOCUMENTS) }
            put("apk", APK)
            listOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz").forEach { put(it, ARCHIVES) }
        }

        fun fromExtension(extension: String): FileCategory = byExtension[extension.lowercase()] ?: OTHER
    }
}
