package com.filemaster.app.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.filemaster.app.FileMasterApp
import com.filemaster.app.MainActivity
import com.filemaster.app.R
import com.filemaster.app.utils.formatSize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Service de premier plan : garde les téléchargements actifs quand l'application n'est plus à l'écran. */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var collectJob: Job? = null
    private var lastStartId = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        ensureChannel()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(null),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        if (collectJob == null) {
            val coordinator = (application as FileMasterApp).container.downloadCoordinator
            val manager = getSystemService(NotificationManager::class.java)
            collectJob = scope.launch {
                coordinator.activeSummary.collect { summary ->
                    if (summary.count == 0) stopSelf(lastStartId)
                    else manager.notify(NOTIFICATION_ID, buildNotification(summary))
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Téléchargements", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(summary: ActiveSummary?): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("FileMaster — téléchargement")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (summary == null) {
            builder.setContentText("Préparation…").setProgress(0, 0, true)
        } else {
            val speed = if (summary.speed > 0) " • ${formatSize(summary.speed)}/s" else ""
            if (summary.total > 0) {
                val percent = (summary.downloaded * 100 / summary.total).toInt().coerceIn(0, 100)
                builder.setContentText("${summary.count} en cours • ${formatSize(summary.downloaded)} / ${formatSize(summary.total)}$speed")
                    .setProgress(100, percent, false)
            } else {
                builder.setContentText("${summary.count} en cours • ${formatSize(summary.downloaded)}$speed")
                    .setProgress(0, 0, true)
            }
        }
        return builder.build()
    }

    companion object {
        private const val CHANNEL_ID = "downloads"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
            } catch (e: Exception) {
                // Démarrage refusé par le système (app en arrière-plan) : le téléchargement continue tant que le processus vit.
            }
        }
    }
}
