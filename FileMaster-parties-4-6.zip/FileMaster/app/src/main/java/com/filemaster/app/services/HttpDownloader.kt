package com.filemaster.app.services

import android.net.Uri
import com.filemaster.app.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Téléchargement HTTP/HTTPS avec reprise (en-tête Range) quand le serveur l'autorise. Aucune bibliothèque externe. */
class HttpDownloader {

    data class Meta(val fileName: String?, val total: Long, val acceptsRanges: Boolean)

    /**
     * Télécharge `url` dans `part`. Reprend à `startAt` si le serveur répond 206 ; sinon recommence de zéro.
     * Retourne le nombre d'octets présents dans `part` à la fin.
     */
    suspend fun download(
        url: String,
        part: File,
        startAt: Long,
        onMeta: suspend (Meta) -> Unit,
        onProgress: suspend (Long) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        var offset = startAt
        var conn = open(url, offset)
        if (conn.responseCode == 416 && offset > 0) {
            // Plage refusée (fichier modifié côté serveur ?) : on repart de zéro.
            conn.disconnect()
            part.delete()
            offset = 0
            conn = open(url, 0)
        }
        val connection = conn
        try {
            coroutineScope {
                // Coupe la connexion si la coroutine est annulée (pause/annulation) : débloque read().
                val watcher = launch {
                    try { awaitCancellation() } finally { runCatching { connection.disconnect() } }
                }
                val code = connection.responseCode
                if (code != 200 && code != 206) throw IOException(httpMessage(code))
                val partial = code == 206
                if (!partial) offset = 0 // le serveur a ignoré Range : on réécrit tout le fichier
                val total = if (partial) totalFromContentRange(connection.getHeaderField("Content-Range"))
                else connection.contentLengthLong
                val accepts = partial || connection.getHeaderField("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
                onMeta(Meta(fileNameFrom(connection), total, accepts))

                val parent = part.parentFile
                parent?.mkdirs()
                val remaining = if (total > 0) total - offset else -1L
                if (remaining > 0 && parent != null && parent.usableSpace < remaining) {
                    throw IOException("Espace de stockage insuffisant")
                }

                var downloaded = offset
                connection.inputStream.use { input ->
                    FileOutputStream(part, offset > 0).use { out ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            ensureActive()
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            downloaded += n
                            onProgress(downloaded)
                        }
                    }
                }
                watcher.cancel()
                downloaded
            }
        } finally {
            runCatching { connection.disconnect() }
        }
    }

    private fun open(url: String, rangeStart: Long): HttpURLConnection {
        var current = URL(url)
        for (i in 0 until MAX_REDIRECTS) {
            val c = current.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", "FileMaster/${BuildConfig.VERSION_NAME}")
            c.setRequestProperty("Accept-Encoding", "identity") // taille annoncée = taille réelle
            if (rangeStart > 0) c.setRequestProperty("Range", "bytes=$rangeStart-")
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                val location = c.getHeaderField("Location") ?: throw IOException("Redirection invalide")
                c.disconnect()
                current = URL(current, location)
                if (current.protocol != "http" && current.protocol != "https") {
                    throw IOException("Protocole non pris en charge : ${current.protocol}")
                }
                continue
            }
            return c
        }
        throw IOException("Trop de redirections")
    }

    private fun totalFromContentRange(header: String?): Long =
        header?.substringAfterLast('/', "")?.toLongOrNull() ?: -1L

    private fun fileNameFrom(conn: HttpURLConnection): String? {
        val cd = conn.getHeaderField("Content-Disposition") ?: return null
        Regex("filename\\*\\s*=\\s*[^']*''([^;]+)", RegexOption.IGNORE_CASE).find(cd)
            ?.groupValues?.get(1)?.let { return sanitizeName(Uri.decode(it)).ifBlank { null } }
        Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
            ?.groupValues?.get(1)?.let { return sanitizeName(it.trim()).ifBlank { null } }
        return null
    }

    private fun httpMessage(code: Int): String = when (code) {
        401, 403 -> "Accès refusé par le serveur (HTTP $code)"
        404 -> "Fichier introuvable sur le serveur (HTTP 404)"
        in 500..599 -> "Erreur du serveur (HTTP $code)"
        else -> "Réponse inattendue du serveur (HTTP $code)"
    }

    companion object {
        private const val MAX_REDIRECTS = 6

        fun sanitizeName(name: String): String =
            name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.').take(120)

        fun fileNameFromUrl(url: String): String {
            val path = runCatching { URL(url).path }.getOrDefault("")
            val last = Uri.decode(path.substringAfterLast('/'))
            return sanitizeName(last).ifBlank { "telechargement" }
        }
    }
}
