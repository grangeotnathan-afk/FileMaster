package com.filemaster.app.features.files

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.utils.elementsLabel
import com.filemaster.app.utils.formatDate
import com.filemaster.app.utils.formatSize
import java.io.File

sealed interface FilesDialog {
    object NewFolder : FilesDialog
    data class Rename(val item: FileItem) : FilesDialog
    data class Delete(val paths: List<String>) : FilesDialog
}

@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val base = initial.substringBeforeLast('.', initial)
    var text by remember { mutableStateOf(TextFieldValue(initial, selection = TextRange(0, base.length))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(label) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text.text) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun DeleteDialog(paths: List<String>, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val names = paths.take(3).map { File(it).name }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Supprimer ${elementsLabel(paths.size)} ?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(names.joinToString("\n") + if (paths.size > 3) "\net ${paths.size - 3} autre(s)…" else "")
                Text(
                    "Suppression définitive : Android n'offre pas de corbeille, ces éléments ne pourront pas être restaurés.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun PropertiesDialog(info: PropertiesInfo, onDismiss: () -> Unit) {
    val item = info.item
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Propriétés") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PropertyRow("Nom", item.name)
                PropertyRow("Emplacement", File(item.path).parent ?: "/")
                PropertyRow("Type", if (item.isDirectory) "Dossier" else (info.mime ?: item.category.label))
                PropertyRow("Taille", info.sizeBytes?.let { formatSize(it) } ?: "Calcul en cours…")
                if (item.isDirectory) {
                    PropertyRow(
                        "Contenu",
                        info.fileCount?.let { "${elementsLabel(it)} (fichiers, récursif)" } ?: "Calcul en cours…"
                    )
                }
                PropertyRow("Modifié le", formatDate(item.lastModified))
                PropertyRow("Lecture", if (info.canRead) "Oui" else "Non")
                PropertyRow("Écriture", if (info.canWrite) "Oui" else "Non")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
private fun PropertyRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(96.dp)
        )
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}
