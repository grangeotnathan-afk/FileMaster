package com.filemaster.app.repository

import android.os.Environment
import android.os.StatFs
import com.filemaster.app.domain.model.StandardFolder
import com.filemaster.app.domain.model.StorageInfo
import java.io.File

@Suppress("DEPRECATION")
class StorageRepository {

    fun root(): File = Environment.getExternalStorageDirectory()

    fun pathOf(folder: StandardFolder): String = File(root(), folder.dirName).absolutePath

    /** Valeurs réelles lues auprès du système (StatFs) pour le stockage interne partagé. */
    fun internalStorage(): StorageInfo? = runCatching {
        val stat = StatFs(root().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        StorageInfo(total = total, used = total - free, free = free)
    }.getOrNull()
}
