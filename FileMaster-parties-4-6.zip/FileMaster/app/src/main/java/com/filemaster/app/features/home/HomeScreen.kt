package com.filemaster.app.features.home

import android.text.format.DateUtils
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ItemSize
import com.filemaster.app.domain.model.OperationRecord
import com.filemaster.app.domain.model.OperationType
import com.filemaster.app.domain.model.ScanStatus
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.domain.model.StorageInfo
import com.filemaster.app.features.permission.StoragePermissionState
import com.filemaster.app.ui.components.FileRow
import com.filemaster.app.ui.components.visual
import com.filemaster.app.utils.FileActions
import com.filemaster.app.utils.formatSize
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    permission: StoragePermissionState,
    onOpenFolder: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenCategory: (SmartCategory) -> Unit,
    viewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory)
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val counts by viewModel.categoryCounts.collectAsStateWithLifecycle()
    val scanStatus by viewModel.scanStatus.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(permission.granted) { if (permission.granted) viewModel.ensureScan() }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refresh() }

    val open: (FileItem) -> Unit = { item ->
        if (item.isDirectory) {
            onOpenFolder(item.path)
        } else {
            viewModel.onFileOpened(item.path)
            FileActions.open(context, File(item.path))
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text("FileMaster", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Gestionnaire de fichiers",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item { SearchPill(onClick = onOpenSearch) }
        item { StorageCard(state.storage) }

        if (!permission.granted) {
            item { PermissionBanner(onRequest = permission.request) }
        }

        item {
            val currentCounts = counts
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Catégories", style = MaterialTheme.typography.titleMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(SmartCategory.values().toList(), key = { it.name }) { category ->
                        val (icon, tint) = category.visual()
                        val countText = when {
                            category == SmartCategory.FAVORITES -> "${state.favoriteCount}"
                            currentCounts != null -> "${currentCounts[category] ?: 0}"
                            scanStatus == ScanStatus.RUNNING -> "…"
                            else -> "—"
                        }
                        Column(
                            modifier = Modifier
                                .width(96.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(tint.copy(alpha = 0.14f))
                                .clickable { onOpenCategory(category) }
                                .padding(vertical = 14.dp, horizontal = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(category.label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                            Text(
                                countText,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        fileSection("Consultés récemment", "Les fichiers que vous ouvrez depuis FileMaster apparaîtront ici.", state.recentOpened, settings.showExtensions, settings.itemSize, open)
        fileSection("Téléchargés récemment", "Aucun fichier dans le dossier Téléchargements.", state.recentDownloads, settings.showExtensions, settings.itemSize, open)
        fileSection("Favoris", "Ajoutez des favoris depuis l'explorateur (sélection longue, puis étoile).", state.favorites, settings.showExtensions, settings.itemSize, open)

        item { ActivityCard(state.activity) }
    }
}

private fun LazyListScope.fileSection(
    title: String,
    emptyText: String,
    items: List<FileItem>,
    showExtension: Boolean,
    itemSize: ItemSize,
    onClick: (FileItem) -> Unit
) {
    item(key = title) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                if (items.isEmpty()) {
                    Text(
                        emptyText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
                    )
                } else {
                    items.forEach { item ->
                        FileRow(item = item, showExtension = showExtension, itemSize = itemSize, onClick = { onClick(item) })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchPill(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(12.dp))
            Text("Rechercher un fichier…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StorageCard(storage: StorageInfo?) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Stockage interne", style = MaterialTheme.typography.labelLarge)
            if (storage == null) {
                Text("Information indisponible", style = MaterialTheme.typography.bodyMedium)
            } else {
                val fraction = (storage.used.toFloat() / storage.total.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
                val animated by animateFloatAsState(targetValue = fraction, animationSpec = tween(800), label = "storage")
                Text(formatSize(storage.used), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text("utilisés sur ${formatSize(storage.total)}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f))
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(animated)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (fraction > 0.9f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    )
                }
                Row(Modifier.fillMaxWidth()) {
                    Text("${(fraction * 100).roundToInt()} % utilisé", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text("${formatSize(storage.free)} disponibles", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun PermissionBanner(onRequest: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.width(12.dp))
            Text(
                "L'accès aux fichiers n'est pas accordé : les listes ci-dessous peuvent être incomplètes.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRequest) { Text("Autoriser") }
        }
    }
}

@Composable
private fun ActivityCard(activity: List<OperationRecord>) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Activité récente", style = MaterialTheme.typography.titleMedium)
            if (activity.isEmpty()) {
                Text(
                    "Les opérations effectuées dans FileMaster (copie, déplacement, suppression…) seront listées ici.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            activity.forEach { op ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        operationIcon(op.type),
                        contentDescription = null,
                        tint = if (op.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(op.description, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                        Text(
                            DateUtils.getRelativeTimeSpanString(op.timestamp, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun operationIcon(type: OperationType): ImageVector = when (type) {
    OperationType.CREATE_FOLDER -> Icons.Rounded.CreateNewFolder
    OperationType.RENAME -> Icons.Rounded.Edit
    OperationType.DELETE -> Icons.Rounded.Delete
    OperationType.COPY -> Icons.Rounded.FileCopy
    OperationType.MOVE -> Icons.Rounded.DriveFileMove
    OperationType.DOWNLOAD -> Icons.Rounded.Download
    OperationType.UNKNOWN -> Icons.Rounded.Edit
}
