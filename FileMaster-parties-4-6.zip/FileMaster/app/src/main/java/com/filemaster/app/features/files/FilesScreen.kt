package com.filemaster.app.features.files

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemaster.app.features.permission.PermissionRequiredContent
import com.filemaster.app.features.permission.StoragePermissionState
import com.filemaster.app.utils.FileActions
import com.filemaster.app.utils.elementsLabel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(
    permission: StoragePermissionState,
    viewModel: FilesViewModel = viewModel(factory = FilesViewModel.Factory)
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var dialog by remember { mutableStateOf<FilesDialog?>(null) }

    LaunchedEffect(permission.granted) { if (permission.granted) viewModel.reload() }
    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.messageShown()
        }
    }

    BackHandler(enabled = state.selected.isNotEmpty() || state.searchActive || state.currentPath != viewModel.rootPath) {
        when {
            state.selected.isNotEmpty() -> viewModel.clearSelection()
            state.searchActive -> viewModel.setSearchActive(false)
            else -> viewModel.goUp()
        }
    }

    if (!permission.granted) {
        PermissionRequiredContent(onRequest = permission.request)
        return
    }

    val displayed = state.displayedItems()
    val selectedItems = displayed.filter { it.path in state.selected }
    val title = if (state.currentPath == viewModel.rootPath) "Stockage interne"
    else File(state.currentPath).name.ifEmpty { "/" }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            when {
                state.selected.isNotEmpty() -> SelectionTopBar(
                    count = state.selected.size,
                    allFavorite = state.selected.all { it in state.favorites },
                    single = state.selected.size == 1,
                    onClose = { viewModel.clearSelection() },
                    onSelectAll = { viewModel.selectAll() },
                    onShare = { FileActions.share(context, state.selected.map { File(it) }) },
                    onFavorite = { viewModel.toggleFavorites() },
                    onCopy = { viewModel.copyToClipboard(move = false) },
                    onCut = { viewModel.copyToClipboard(move = true) },
                    onDelete = { dialog = FilesDialog.Delete(state.selected.toList()) },
                    onRename = { selectedItems.firstOrNull()?.let { dialog = FilesDialog.Rename(it) } },
                    onProperties = { state.selected.firstOrNull()?.let { viewModel.showProperties(it) } }
                )
                state.searchActive -> SearchTopBar(
                    folderName = title,
                    query = state.query,
                    onQueryChange = { viewModel.onQueryChange(it) },
                    onClose = { viewModel.setSearchActive(false) }
                )
                else -> NormalTopBar(
                    title = title,
                    state = state,
                    onBack = { viewModel.goBack() },
                    onForward = { viewModel.goForward() },
                    onSearch = { viewModel.setSearchActive(true) },
                    onToggleLayout = { viewModel.toggleLayout() },
                    onSort = { viewModel.setSort(it) },
                    onToggleHidden = { viewModel.toggleHidden() },
                    onRefresh = { viewModel.reload() }
                )
            }
        },
        floatingActionButton = {
            if (state.selected.isEmpty() && !state.searchActive) {
                FloatingActionButton(onClick = { dialog = FilesDialog.NewFolder }) {
                    Icon(Icons.Rounded.CreateNewFolder, contentDescription = "Nouveau dossier")
                }
            }
        },
        bottomBar = {
            state.clipboard?.let { clip ->
                Surface(color = MaterialTheme.colorScheme.primaryContainer, tonalElevation = 0.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${elementsLabel(clip.paths.size)} à ${if (clip.move) "déplacer" else "copier"}",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        TextButton(onClick = { viewModel.cancelClipboard() }) { Text("Annuler") }
                        Button(onClick = { viewModel.paste() }, enabled = !state.busy) { Text("Coller ici") }
                    }
                }
            }
        }
    ) { padding ->
        FilesContent(
            state = state,
            rootPath = viewModel.rootPath,
            modifier = Modifier.padding(padding),
            onNavigate = { viewModel.navigateTo(it) },
            onItemClick = { item ->
                when {
                    state.selected.isNotEmpty() -> viewModel.toggleSelect(item.path)
                    item.isDirectory -> viewModel.navigateTo(item.path)
                    else -> {
                        viewModel.onFileOpened(item.path)
                        FileActions.open(context, File(item.path))
                    }
                }
            },
            onItemLongClick = { viewModel.toggleSelect(it.path) },
            onExtensionFilter = { viewModel.setExtensionFilter(it) },
            onRetry = { viewModel.reload() }
        )
    }

    when (val d = dialog) {
        FilesDialog.NewFolder -> TextInputDialog(
            title = "Nouveau dossier",
            label = "Nom du dossier",
            initial = "",
            confirmLabel = "Créer",
            onConfirm = { viewModel.createFolder(it); dialog = null },
            onDismiss = { dialog = null }
        )
        is FilesDialog.Rename -> TextInputDialog(
            title = "Renommer",
            label = "Nouveau nom",
            initial = d.item.name,
            confirmLabel = "Renommer",
            onConfirm = { viewModel.rename(d.item.path, it); viewModel.clearSelection(); dialog = null },
            onDismiss = { dialog = null }
        )
        is FilesDialog.Delete -> DeleteDialog(
            paths = d.paths,
            onConfirm = { viewModel.delete(d.paths); dialog = null },
            onDismiss = { dialog = null }
        )
        null -> Unit
    }

    state.properties?.let { PropertiesDialog(info = it, onDismiss = { viewModel.dismissProperties() }) }
}
