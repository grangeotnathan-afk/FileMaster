package com.filemaster.app.domain.model

enum class ScanStatus { IDLE, RUNNING, DONE }

/** Résultat d'un parcours complet du stockage interne (partagé entre catégories et analyse). */
data class ScanState(
    val status: ScanStatus = ScanStatus.IDLE,
    val filesFound: Int = 0,
    /** Dossiers que le système a refusé de lister : ils ne sont PAS comptés dans l'analyse. */
    val skippedDirs: Int = 0,
    val files: List<FileItem> = emptyList(),
    /** Taille directe (hors sous-dossiers) des fichiers de chaque dossier. */
    val dirSizes: Map<String, Long> = emptyMap(),
    val finishedAt: Long? = null
)
