package com.filemaster.app.utils

import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.SortField
import com.filemaster.app.domain.model.SortOption

object FileSorting {
    /** Les dossiers sont toujours placés avant les fichiers. */
    fun comparator(sort: SortOption): Comparator<FileItem> {
        val byName: Comparator<FileItem> = compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        val base: Comparator<FileItem> = when (sort.field) {
            SortField.NAME -> byName
            SortField.SIZE -> compareBy<FileItem> { it.size }.then(byName)
            SortField.DATE -> compareBy<FileItem> { it.lastModified }.then(byName)
            SortField.TYPE -> compareBy<FileItem> { it.extension }.then(byName)
        }
        val directed = if (sort.ascending) base else base.reversed()
        return compareByDescending<FileItem> { it.isDirectory }.then(directed)
    }
}
