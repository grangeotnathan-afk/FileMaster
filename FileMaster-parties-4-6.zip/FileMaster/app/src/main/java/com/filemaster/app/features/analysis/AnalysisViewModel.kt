package com.filemaster.app.features.analysis

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.analysis.StorageAnalyzer
import com.filemaster.app.domain.model.AnalysisResult
import com.filemaster.app.domain.model.DuplicateGroup
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.OperationType
import com.filemaster.app.domain.model.ScanState
import com.filemaster.app.domain.model.ScanStatus
import com.filemaster.app.domain.model.StorageInfo
import com.filemaster.app.repository.DuplicateProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class AnalysisTab(val label: String) {
    OVERVIEW("Aperçu"),
    LARGEST("Gros fichiers"),
    FOLDERS("Dossiers"),
    DUPLICATES("Doublons"),
    OLD("Anciens"),
    JUNK("Inutiles")
}

enum class OldThreshold(val label: String, val days: Int) {
    SIX_MONTHS("6 mois", 182),
    ONE_YEAR("1 an", 365),
    TWO_YEARS("2 ans", 730)
}

sealed interface DuplicateState {
    object Idle : DuplicateState
    data class Running(val progress: DuplicateProgress) : DuplicateState
    data class Done(val groups: List<DuplicateGroup>) : DuplicateState
}

data class AnalysisUiState(
    val scan: ScanState = ScanState(),
    val result: AnalysisResult? = null,
    val storage: StorageInfo? = null,
    val tab: AnalysisTab = AnalysisTab.OVERVIEW,
    val oldThreshold: OldThreshold = OldThreshold.ONE_YEAR,
    val oldFiles: List<FileItem> = emptyList(),
    val duplicates: DuplicateState = DuplicateState.Idle,
    /** Éléments cochés : chemin -> taille. Rien n'est jamais supprimé sans confirmation. */
    val selected: Map<String, Long> = emptyMap(),
    val busy: Boolean = false,
    val message: String? = null
)

class AnalysisViewModel(private val c: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(AnalysisUiState())
    val state: StateFlow<AnalysisUiState> = _state.asStateFlow()
    private var duplicateJob: Job? = null

    val rootPath: String = c.storageRepository.root().absolutePath

    init {
        viewModelScope.launch {
            c.scanRepository.state.collect { scan ->
                _state.update { it.copy(scan = scan) }
                if (scan.status == ScanStatus.DONE) recompute(scan) else _state.update { it.copy(result = null, oldFiles = emptyList()) }
            }
        }
    }

    private suspend fun recompute(scan: ScanState) {
        val threshold = _state.value.oldThreshold
        val (result, old) = withContext(Dispatchers.Default) {
            val now = System.currentTimeMillis()
            AnalysisResult(
                totalSize = scan.files.sumOf { it.size },
                fileCount = scan.files.size,
                categories = StorageAnalyzer.categoryStats(scan.files),
                largest = StorageAnalyzer.largest(scan.files),
                folders = StorageAnalyzer.folderStats(scan.dirSizes, rootPath),
                junk = StorageAnalyzer.junk(scan.files)
            ) to StorageAnalyzer.oldFiles(scan.files, now, threshold.days)
        }
        val storage = withContext(Dispatchers.IO) { c.storageRepository.internalStorage() }
        _state.update { it.copy(result = result, oldFiles = old, storage = storage) }
    }

    fun startScan() {
        c.scanRepository.start(c.storageRepository.root(), force = true)
    }

    fun setTab(tab: AnalysisTab) {
        _state.update { it.copy(tab = tab, selected = emptyMap()) }
    }

    fun setOldThreshold(threshold: OldThreshold) {
        _state.update { it.copy(oldThreshold = threshold, selected = emptyMap()) }
        viewModelScope.launch {
            val files = _state.value.scan.files
            val old = withContext(Dispatchers.Default) {
                StorageAnalyzer.oldFiles(files, System.currentTimeMillis(), threshold.days)
            }
            _state.update { it.copy(oldFiles = old) }
        }
    }

    // ------------------------------------------------------------ doublons

    fun findDuplicates() {
        if (duplicateJob?.isActive == true) return
        duplicateJob = viewModelScope.launch {
            _state.update { it.copy(duplicates = DuplicateState.Running(DuplicateProgress(0, 0, "Préparation")), selected = emptyMap()) }
            val groups = c.duplicateFinder.find(_state.value.scan.files) { p ->
                _state.update { it.copy(duplicates = DuplicateState.Running(p)) }
            }
            _state.update { it.copy(duplicates = DuplicateState.Done(groups)) }
        }
    }

    /** Présélection facultative : coche toutes les copies sauf la plus ancienne de chaque groupe. */
    fun preselectDuplicateCopies() {
        val groups = (_state.value.duplicates as? DuplicateState.Done)?.groups ?: return
        val selection = HashMap<String, Long>()
        for (g in groups) g.files.drop(1).forEach { selection[it.path] = it.size }
        _state.update { it.copy(selected = selection) }
    }

    // ------------------------------------------------------------ sélection / suppression

    fun toggle(item: FileItem) {
        _state.update {
            it.copy(selected = if (item.path in it.selected) it.selected - item.path else it.selected + (item.path to item.size))
        }
    }

    fun clearSelection() {
        _state.update { it.copy(selected = emptyMap()) }
    }

    fun messageShown() {
        _state.update { it.copy(message = null) }
    }

    /** À appeler uniquement après la confirmation de l'utilisateur. */
    fun deleteSelected() {
        val s = _state.value
        val paths = s.selected.keys.toList()
        if (paths.isEmpty()) return
        val dup = s.duplicates
        if (s.tab == AnalysisTab.DUPLICATES && dup is DuplicateState.Done &&
            dup.groups.any { g -> g.files.all { it.path in s.selected } }
        ) {
            _state.update { it.copy(message = "Gardez au moins une copie de chaque groupe de doublons.") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val result = c.fileRepository.delete(paths.map(::File))
            val gone = withContext(Dispatchers.IO) { paths.filter { !File(it).exists() }.toSet() }
            if (gone.isNotEmpty()) {
                c.favoritesRepository.remove(gone.toList())
                c.recentRepository.remove(gone.toList())
                c.scanRepository.removeFiles(gone)
            }
            val description = "Analyse : ${result.successCount} fichier(s) supprimé(s)" +
                if (result.errors.isNotEmpty()) ", ${result.errors.size} échec(s)" else ""
            c.historyRepository.log(OperationType.DELETE, description, result.errors.isEmpty())
            _state.update { st ->
                val d = st.duplicates
                st.copy(
                    busy = false,
                    selected = emptyMap(),
                    duplicates = if (d is DuplicateState.Done) {
                        DuplicateState.Done(
                            d.groups.map { g -> g.copy(files = g.files.filter { it.path !in gone }) }.filter { it.files.size >= 2 }
                        )
                    } else d,
                    message = if (result.errors.isEmpty()) description else "$description — ${result.errors.first()}"
                )
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                AnalysisViewModel(app.container)
            }
        }
    }
}
