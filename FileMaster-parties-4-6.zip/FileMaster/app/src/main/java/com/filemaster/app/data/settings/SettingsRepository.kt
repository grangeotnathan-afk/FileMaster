package com.filemaster.app.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.ItemSize
import com.filemaster.app.domain.model.LayoutMode
import com.filemaster.app.domain.model.SortField
import com.filemaster.app.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Préférences enregistrées localement (DataStore). */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val themeMode = stringPreferencesKey("theme_mode")
        val primaryColor = longPreferencesKey("primary_color")
        val layoutMode = stringPreferencesKey("layout_mode")
        val itemSize = stringPreferencesKey("item_size")
        val showExtensions = booleanPreferencesKey("show_extensions")
        val showHidden = booleanPreferencesKey("show_hidden")
        val sortField = stringPreferencesKey("sort_field")
        val sortAscending = booleanPreferencesKey("sort_ascending")
        val startFolder = stringPreferencesKey("start_folder")
        val downloadFolder = stringPreferencesKey("download_folder")
    }

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                themeMode = p[Keys.themeMode].toEnum(d.themeMode),
                primaryColor = p[Keys.primaryColor] ?: d.primaryColor,
                layoutMode = p[Keys.layoutMode].toEnum(d.layoutMode),
                itemSize = p[Keys.itemSize].toEnum(d.itemSize),
                showExtensions = p[Keys.showExtensions] ?: d.showExtensions,
                showHidden = p[Keys.showHidden] ?: d.showHidden,
                sortField = p[Keys.sortField].toEnum(d.sortField),
                sortAscending = p[Keys.sortAscending] ?: d.sortAscending,
                startFolder = p[Keys.startFolder] ?: d.startFolder,
                downloadFolder = p[Keys.downloadFolder] ?: d.downloadFolder
            )
        }

    private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
        this?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: default

    suspend fun setThemeMode(value: ThemeMode) { context.dataStore.edit { it[Keys.themeMode] = value.name } }
    suspend fun setPrimaryColor(value: Long) { context.dataStore.edit { it[Keys.primaryColor] = value } }
    suspend fun setLayoutMode(value: LayoutMode) { context.dataStore.edit { it[Keys.layoutMode] = value.name } }
    suspend fun setItemSize(value: ItemSize) { context.dataStore.edit { it[Keys.itemSize] = value.name } }
    suspend fun setShowExtensions(value: Boolean) { context.dataStore.edit { it[Keys.showExtensions] = value } }
    suspend fun setShowHidden(value: Boolean) { context.dataStore.edit { it[Keys.showHidden] = value } }
    suspend fun setSortField(value: SortField) { context.dataStore.edit { it[Keys.sortField] = value.name } }
    suspend fun setSortAscending(value: Boolean) { context.dataStore.edit { it[Keys.sortAscending] = value } }
    suspend fun setStartFolder(value: String) { context.dataStore.edit { it[Keys.startFolder] = value } }
    suspend fun setDownloadFolder(value: String) { context.dataStore.edit { it[Keys.downloadFolder] = value } }
}
