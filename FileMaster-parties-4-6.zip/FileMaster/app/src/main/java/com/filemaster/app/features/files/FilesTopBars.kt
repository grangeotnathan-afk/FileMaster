package com.filemaster.app.features.files

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import com.filemaster.app.domain.model.LayoutMode
import com.filemaster.app.domain.model.SortField
import com.filemaster.app.ui.theme.StarColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NormalTopBar(
    title: String,
    state: FilesUiState,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onSearch: () -> Unit,
    onToggleLayout: () -> Unit,
    onSort: (SortField) -> Unit,
    onToggleHidden: () -> Unit,
    onRefresh: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            IconButton(onClick = onBack, enabled = state.canGoBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Dossier précédent")
            }
        },
        actions = {
            IconButton(onClick = onForward, enabled = state.canGoForward) {
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Dossier suivant")
            }
            IconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, contentDescription = "Rechercher") }
            IconButton(onClick = onToggleLayout) {
                if (state.settings.layoutMode == LayoutMode.LIST) {
                    Icon(Icons.Rounded.GridView, contentDescription = "Afficher en grille")
                } else {
                    Icon(Icons.Rounded.ViewList, contentDescription = "Afficher en liste")
                }
            }
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = "Plus") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SortField.values().forEach { field ->
                    DropdownMenuItem(
                        text = { Text("Trier par ${field.label.lowercase()}") },
                        onClick = { onSort(field); menu = false },
                        trailingIcon = {
                            if (state.sort.field == field) {
                                Icon(
                                    if (state.sort.ascending) Icons.Rounded.ArrowUpward else Icons.Rounded.ArrowDownward,
                                    contentDescription = null
                                )
                            }
                        }
                    )
                }
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text(if (state.showHidden) "Masquer les fichiers cachés" else "Afficher les fichiers cachés") },
                    onClick = { onToggleHidden(); menu = false }
                )
                DropdownMenuItem(text = { Text("Actualiser") }, onClick = { onRefresh(); menu = false })
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectionTopBar(
    count: Int,
    allFavorite: Boolean,
    single: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onShare: () -> Unit,
    onFavorite: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onProperties: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    TopAppBar(
        title = { Text("$count sélectionné(s)") },
        navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = "Annuler la sélection") } },
        actions = {
            IconButton(onClick = onSelectAll) { Icon(Icons.Rounded.SelectAll, contentDescription = "Tout sélectionner") }
            IconButton(onClick = onShare) { Icon(Icons.Rounded.Share, contentDescription = "Partager") }
            IconButton(onClick = onFavorite) {
                if (allFavorite) Icon(Icons.Rounded.Star, contentDescription = "Retirer des favoris", tint = StarColor)
                else Icon(Icons.Rounded.StarBorder, contentDescription = "Ajouter aux favoris")
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Supprimer") }
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = "Plus") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Copier") }, onClick = { onCopy(); menu = false })
                DropdownMenuItem(text = { Text("Déplacer") }, onClick = { onCut(); menu = false })
                if (single) {
                    DropdownMenuItem(text = { Text("Renommer") }, onClick = { onRename(); menu = false })
                    DropdownMenuItem(text = { Text("Propriétés") }, onClick = { onProperties(); menu = false })
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchTopBar(folderName: String, query: String, onQueryChange: (String) -> Unit, onClose: () -> Unit) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    TopAppBar(
        navigationIcon = {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Fermer la recherche") }
        },
        title = {
            TextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { Text("Rechercher dans $folderName", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        },
        actions = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) { Icon(Icons.Rounded.Close, contentDescription = "Effacer") }
            }
        }
    )
}
