package com.filemaster.app.domain.model

enum class SmartCategory(val label: String, val title: String) {
    IMAGES("Images", "Images"),
    VIDEOS("Vidéos", "Vidéos"),
    AUDIO("Musique", "Musique"),
    DOCUMENTS("Documents", "Documents"),
    APK("APK", "Fichiers APK"),
    ARCHIVES("Archives", "Archives"),
    DOWNLOADS("Téléch.", "Téléchargements"),
    LARGE("Volumineux", "Fichiers volumineux (≥ 100 Mo)"),
    RECENT("Récents", "Fichiers récents (7 jours)"),
    FAVORITES("Favoris", "Favoris");

    companion object {
        fun fromName(name: String?): SmartCategory? = values().firstOrNull { it.name == name }
    }
}
