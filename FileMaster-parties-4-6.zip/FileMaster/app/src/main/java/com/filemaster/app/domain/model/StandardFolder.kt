package com.filemaster.app.domain.model

/** Dossiers standards du stockage interne, utilisés comme raccourcis. */
enum class StandardFolder(val label: String, val dirName: String) {
    DOWNLOADS("Téléchargements", "Download"),
    PICTURES("Images", "Pictures"),
    CAMERA("Appareil photo", "DCIM"),
    MUSIC("Musique", "Music"),
    MOVIES("Vidéos", "Movies"),
    DOCUMENTS("Documents", "Documents")
}
