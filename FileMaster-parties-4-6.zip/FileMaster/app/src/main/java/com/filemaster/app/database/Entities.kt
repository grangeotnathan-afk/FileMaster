package com.filemaster.app.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val path: String,
    val addedAt: Long
)

@Entity(tableName = "recent_files")
data class RecentFileEntity(
    @PrimaryKey val path: String,
    val openedAt: Long
)

@Entity(tableName = "operation_history")
data class OperationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val description: String,
    val success: Boolean,
    val timestamp: Long
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val fileName: String,
    val destDir: String,
    /** -1 si la taille n'est pas annoncée par le serveur. */
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: String,
    val error: String?,
    val acceptsRanges: Boolean,
    val createdAt: Long,
    val finishedAt: Long?
)
