package com.filemaster.app.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.filemaster.app.domain.model.AnalysisResult
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.FileCategory
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ScanState
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.ui.components.DonutChart
import com.filemaster.app.ui.components.FileRow
import com.filemaster.app.ui.components.color
import com.filemaster.app.ui.theme.FolderColor
import com.filemaster.app.utils.formatSize
import java.io.File
import kotlin.math.roundToInt

private fun FileCategory.toSmart(): SmartCategory? = when (this) {
    FileCategory.IMAGES -> SmartCategory.IMAGES
    FileCategory.VIDEOS -> SmartCategory.VIDEOS
    FileCategory.AUDIO -> SmartCategory.AUDIO
    FileCategory.DOCUMENTS -> SmartCategory.DOCUMENTS
    FileCategory.APK -> SmartCategory.APK
    FileCategory.ARCHIVES -> SmartCategory.ARCHIVES
    FileCategory.OTHER -> null
}

private fun relativeParent(path: String, root: String): String =
    (File(path).parent ?: "/").removePrefix(root).ifEmpty { "/" }

fun LazyListScope.overviewTab(
    result: AnalysisResult,
    scan: ScanState,
    usedByStorage: Long?,
    totalStorage: Long?,
    onOpenCategory: (SmartCategory) -> Unit
) {
    item {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                DonutChart(
                    slices = result.categories.map { it.category.color() to it.size.toFloat() },
                    trackColor = MaterialTheme.colorScheme.background,
                    modifier = Modifier.size(190.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(formatSize(result.totalSize), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("analysés", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("${result.fileCount} fichiers parcourus", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
    item {
        // Transparence : ce que l'analyse n'a PAS pu voir.
        val notAnalyzed = if (usedByStorage != null) (usedByStorage - result.totalSize).coerceAtLeast(0L) else null
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Limites de l'analyse", style = MaterialTheme.typography.titleSmall)
                if (usedByStorage != null && totalStorage != null) {
                    Text("Espace utilisé selon Android : ${formatSize(usedByStorage)}", style = MaterialTheme.typography.bodySmall)
                }
                if (notAnalyzed != null) {
                    Text(
                        "Non visible pour FileMaster : environ ${formatSize(notAnalyzed)} (système, applications, données protégées par Android).",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    "${scan.skippedDirs} dossier(s) refusé(s) par Android, ignorés.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
    items(result.categories, key = { it.category.name }) { stat ->
        val smart = stat.category.toSmart()
        val fraction = if (result.totalSize > 0) stat.size.toFloat() / result.totalSize else 0f
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable(enabled = smart != null) { smart?.let(onOpenCategory) }
                .padding(horizontal = 4.dp, vertical = 6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(stat.category.color()))
                Spacer(Modifier.width(10.dp))
                Text(stat.category.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Text(
                    "${formatSize(stat.size)} • ${stat.count}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0.01f, 1f)).clip(RoundedCornerShape(3.dp))
                        .background(stat.category.color())
                )
            }
        }
    }
}

fun LazyListScope.selectableFiles(
    files: List<FileItem>,
    selected: Map<String, Long>,
    settings: AppSettings,
    rootPath: String,
    reasons: Map<String, String> = emptyMap(),
    onToggle: (FileItem) -> Unit,
    onOpen: (FileItem) -> Unit
) {
    if (files.isEmpty()) {
        item { EmptyHint("Rien à signaler ici.") }
        return
    }
    item { EmptyHint("Touchez pour sélectionner, appui long pour ouvrir. Rien n'est supprimé sans votre confirmation.") }
    items(files, key = { it.path }) { item ->
        FileRow(
            item = item,
            showExtension = true,
            itemSize = settings.itemSize,
            selected = item.path in selected,
            extraLine = reasons[item.path] ?: relativeParent(item.path, rootPath),
            onClick = { onToggle(item) },
            onLongClick = { onOpen(item) }
        )
    }
}

fun LazyListScope.foldersTab(result: AnalysisResult, rootPath: String, onOpenFolder: (String) -> Unit) {
    if (result.folders.isEmpty()) {
        item { EmptyHint("Aucun dossier à afficher.") }
        return
    }
    item { EmptyHint("Dossiers de premier et deuxième niveau, tailles cumulées. Touchez pour ouvrir dans l'explorateur.") }
    items(result.folders, key = { it.path }) { folder ->
        val fraction = if (result.totalSize > 0) folder.size.toFloat() / result.totalSize else 0f
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onOpenFolder(folder.path) }
                .padding(horizontal = 4.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Folder, contentDescription = null, tint = FolderColor)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(File(folder.path).name, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    Text(
                        relativeParent(folder.path, rootPath),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                Text(
                    "${formatSize(folder.size)} • ${(fraction * 100).roundToInt()} %",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0.01f, 1f)).clip(RoundedCornerShape(3.dp))
                        .background(FolderColor)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
fun LazyListScope.oldTab(
    state: AnalysisUiState,
    settings: AppSettings,
    rootPath: String,
    onThreshold: (OldThreshold) -> Unit,
    onToggle: (FileItem) -> Unit,
    onOpen: (FileItem) -> Unit
) {
    item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                "Fichiers non modifiés depuis… (Android ne fournit pas de date de dernière ouverture fiable)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OldThreshold.values().forEach { t ->
                    FilterChip(selected = state.oldThreshold == t, onClick = { onThreshold(t) }, label = { Text(t.label) })
                }
            }
        }
    }
    selectableFiles(state.oldFiles, state.selected, settings, rootPath, onToggle = onToggle, onOpen = onOpen)
}

fun LazyListScope.duplicatesTab(
    state: AnalysisUiState,
    settings: AppSettings,
    rootPath: String,
    onFind: () -> Unit,
    onPreselect: () -> Unit,
    onToggle: (FileItem) -> Unit,
    onOpen: (FileItem) -> Unit
) {
    when (val d = state.duplicates) {
        DuplicateState.Idle -> item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                EmptyHint(
                    "Les doublons sont détectés par empreinte SHA-256 : deux fichiers ne sont signalés que si leur contenu est strictement identique. " +
                        "L'opération peut durer plusieurs minutes."
                )
                Button(onClick = onFind) { Text("Rechercher les doublons") }
            }
        }
        is DuplicateState.Running -> item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${d.progress.phase} : ${d.progress.done} / ${d.progress.total}", style = MaterialTheme.typography.bodyMedium)
                if (d.progress.total > 0) {
                    LinearProgressIndicator(progress = { d.progress.done.toFloat() / d.progress.total }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }
        is DuplicateState.Done -> {
            if (d.groups.isEmpty()) {
                item { EmptyHint("Aucun doublon trouvé.") }
                item { OutlinedButton(onClick = onFind) { Text("Relancer la recherche") } }
            } else {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "${d.groups.size} groupe(s) • ${formatSize(d.groups.sumOf { it.wasted })} récupérables",
                            style = MaterialTheme.typography.titleSmall
                        )
                        OutlinedButton(onClick = onPreselect) { Text("Présélectionner les copies (garder la plus ancienne)") }
                    }
                }
                d.groups.forEachIndexed { index, group ->
                    item(key = "g-${group.hash}") {
                        Text(
                            "Groupe ${index + 1} • ${group.files.size} copies de ${formatSize(group.size)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    items(group.files, key = { "${group.hash}-${it.path}" }) { item ->
                        FileRow(
                            item = item,
                            showExtension = true,
                            itemSize = settings.itemSize,
                            selected = item.path in state.selected,
                            extraLine = relativeParent(item.path, rootPath),
                            onClick = { onToggle(item) },
                            onLongClick = { onOpen(item) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}
