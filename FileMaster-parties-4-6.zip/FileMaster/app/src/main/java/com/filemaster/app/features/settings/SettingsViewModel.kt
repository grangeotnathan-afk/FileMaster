package com.filemaster.app.features.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.ItemSize
import com.filemaster.app.domain.model.LayoutMode
import com.filemaster.app.domain.model.SortField
import com.filemaster.app.domain.model.StandardFolder
import com.filemaster.app.domain.model.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val c: AppContainer) : ViewModel() {

    val settings: StateFlow<AppSettings> = c.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    /** Choix de dossier d'ouverture : (chemin, libellé). Chemin vide = racine du stockage interne. */
    val startFolderChoices: List<Pair<String, String>> =
        listOf("" to "Stockage interne") + StandardFolder.values().map { c.storageRepository.pathOf(it) to it.label }

    fun setThemeMode(value: ThemeMode) { viewModelScope.launch { c.settingsRepository.setThemeMode(value) } }
    fun setPrimaryColor(value: Long) { viewModelScope.launch { c.settingsRepository.setPrimaryColor(value) } }
    fun setLayoutMode(value: LayoutMode) { viewModelScope.launch { c.settingsRepository.setLayoutMode(value) } }
    fun setItemSize(value: ItemSize) { viewModelScope.launch { c.settingsRepository.setItemSize(value) } }
    fun setShowExtensions(value: Boolean) { viewModelScope.launch { c.settingsRepository.setShowExtensions(value) } }
    fun setShowHidden(value: Boolean) { viewModelScope.launch { c.settingsRepository.setShowHidden(value) } }
    fun setSortField(value: SortField) { viewModelScope.launch { c.settingsRepository.setSortField(value) } }
    fun setSortAscending(value: Boolean) { viewModelScope.launch { c.settingsRepository.setSortAscending(value) } }
    fun setStartFolder(value: String) { viewModelScope.launch { c.settingsRepository.setStartFolder(value) } }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                SettingsViewModel(app.container)
            }
        }
    }
}
