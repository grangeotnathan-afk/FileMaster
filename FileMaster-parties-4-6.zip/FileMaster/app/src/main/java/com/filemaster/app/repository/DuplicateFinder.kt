package com.filemaster.app.repository

import com.filemaster.app.domain.model.DuplicateGroup
import com.filemaster.app.domain.model.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.security.MessageDigest

data class DuplicateProgress(val done: Int, val total: Int, val phase: String)

/**
 * Détection de doublons par EMPREINTE SHA-256 :
 * 1) regroupement par taille exacte, 2) empreinte des 64 premiers Ko, 3) empreinte du fichier complet.
 * Deux fichiers ne sont déclarés identiques que si leurs empreintes complètes sont égales.
 */
class DuplicateFinder {

    suspend fun find(files: List<FileItem>, onProgress: (DuplicateProgress) -> Unit): List<DuplicateGroup> =
        withContext(Dispatchers.IO) {
            val sameSize = files.asSequence()
                .filter { it.size > 0 }
                .groupBy { it.size }
                .filterValues { it.size >= 2 }
            val stage1 = sameSize.values.flatten()
            var total = stage1.size
            var done = 0
            onProgress(DuplicateProgress(0, total, "Empreinte rapide"))

            val partial = HashMap<String, MutableList<FileItem>>()
            for (f in stage1) {
                ensureActive()
                hash(File(f.path), PARTIAL_BYTES)?.let { partial.getOrPut("${f.size}:$it") { mutableListOf() } += f }
                done++
                if (done % 20 == 0) onProgress(DuplicateProgress(done, total, "Empreinte rapide"))
            }

            val candidates = partial.values.filter { it.size >= 2 }
            total += candidates.sumOf { it.size }
            onProgress(DuplicateProgress(done, total, "Vérification complète"))

            val groups = ArrayList<DuplicateGroup>()
            for (group in candidates) {
                val byHash = HashMap<String, MutableList<FileItem>>()
                for (f in group) {
                    ensureActive()
                    hash(File(f.path), null)?.let { byHash.getOrPut(it) { mutableListOf() } += f }
                    done++
                    if (done % 5 == 0) onProgress(DuplicateProgress(done, total, "Vérification complète"))
                }
                for ((h, list) in byHash) {
                    if (list.size >= 2) groups += DuplicateGroup(list.first().size, h, list.sortedBy { it.lastModified })
                }
            }
            onProgress(DuplicateProgress(total, total, "Terminé"))
            groups.sortedByDescending { it.wasted }
        }

    private fun hash(file: File, limit: Long?): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            var remaining = limit ?: Long.MAX_VALUE
            while (remaining > 0) {
                val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (n < 0) break
                md.update(buffer, 0, n)
                remaining -= n
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: IOException) {
        null
    }

    private companion object {
        const val PARTIAL_BYTES = 64L * 1024
    }
}
