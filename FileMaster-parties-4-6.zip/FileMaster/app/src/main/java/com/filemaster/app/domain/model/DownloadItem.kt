package com.filemaster.app.domain.model

enum class DownloadStatus(val label: String) {
    QUEUED("En attente"),
    DOWNLOADING("Téléchargement"),
    PAUSED("En pause"),
    COMPLETED("Terminé"),
    FAILED("Échec"),
    CANCELED("Annulé");

    companion object {
        fun fromName(name: String): DownloadStatus = values().firstOrNull { it.name == name } ?: FAILED
    }
}

data class DownloadItem(
    val id: Long,
    val url: String,
    val fileName: String,
    val destDir: String,
    val status: DownloadStatus,
    val downloadedBytes: Long,
    /** -1 si inconnue. */
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val error: String?,
    val acceptsRanges: Boolean,
    val createdAt: Long,
    val finishedAt: Long?
)
