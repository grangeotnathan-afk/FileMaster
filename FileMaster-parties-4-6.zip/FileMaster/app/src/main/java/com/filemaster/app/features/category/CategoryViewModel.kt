package com.filemaster.app.features.category

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.analysis.CategoryRules
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ScanStatus
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.domain.model.StandardFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CategoryUiState(
    val status: ScanStatus = ScanStatus.IDLE,
    val filesFound: Int = 0,
    val items: List<FileItem> = emptyList(),
    val totalSize: Long = 0L,
    val skippedDirs: Int = 0,
    val finishedAt: Long? = null,
    val settings: AppSettings = AppSettings()
)

class CategoryViewModel(private val c: AppContainer, handle: SavedStateHandle) : ViewModel() {

    val category: SmartCategory = SmartCategory.fromName(handle.get<String>("id")) ?: SmartCategory.IMAGES
    private val downloadsPath = c.storageRepository.pathOf(StandardFolder.DOWNLOADS)

    val state: StateFlow<CategoryUiState> = combine(
        c.scanRepository.state,
        c.favoritesRepository.observePaths(),
        c.settingsRepository.settings
    ) { scan, favoritePaths, settings ->
        if (category == SmartCategory.FAVORITES) {
            val items = favoritePaths.mapNotNull { c.fileRepository.itemOrNull(it) }
            CategoryUiState(
                status = ScanStatus.DONE,
                items = items,
                totalSize = items.filter { !it.isDirectory }.sumOf { it.size },
                settings = settings
            )
        } else {
            val items = if (scan.status == ScanStatus.DONE) CategoryRules.filter(scan.files, category, downloadsPath) else emptyList()
            CategoryUiState(
                status = scan.status,
                filesFound = scan.filesFound,
                items = items,
                totalSize = items.sumOf { it.size },
                skippedDirs = scan.skippedDirs,
                finishedAt = scan.finishedAt,
                settings = settings
            )
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CategoryUiState())

    init {
        if (category != SmartCategory.FAVORITES) c.scanRepository.start(c.storageRepository.root())
    }

    fun rescan() {
        c.scanRepository.start(c.storageRepository.root(), force = true)
    }

    fun onFileOpened(path: String) {
        viewModelScope.launch { c.recentRepository.record(path) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                CategoryViewModel(app.container, createSavedStateHandle())
            }
        }
    }
}
