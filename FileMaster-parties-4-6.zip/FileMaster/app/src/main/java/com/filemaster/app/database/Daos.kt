package com.filemaster.app.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<FavoriteEntity>)

    @Query("DELETE FROM favorites WHERE path IN (:paths)")
    suspend fun deleteAll(paths: List<String>)

    @Query("UPDATE OR REPLACE favorites SET path = :newPath WHERE path = :oldPath")
    suspend fun rename(oldPath: String, newPath: String)
}

@Dao
interface RecentDao {
    @Query("SELECT * FROM recent_files ORDER BY openedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<RecentFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: RecentFileEntity)

    @Query("DELETE FROM recent_files WHERE path IN (:paths)")
    suspend fun deleteAll(paths: List<String>)

    @Query("DELETE FROM recent_files WHERE path NOT IN (SELECT path FROM recent_files ORDER BY openedAt DESC LIMIT :keep)")
    suspend fun trim(keep: Int)
}

@Dao
interface OperationDao {
    @Query("SELECT * FROM operation_history ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<OperationEntity>>

    @Insert
    suspend fun insert(item: OperationEntity)

    @Query("DELETE FROM operation_history WHERE id NOT IN (SELECT id FROM operation_history ORDER BY timestamp DESC LIMIT :keep)")
    suspend fun trim(keep: Int)

    @Query("DELETE FROM operation_history")
    suspend fun clear()
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun get(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('COMPLETED', 'FAILED', 'CANCELED')")
    suspend fun getFinished(): List<DownloadEntity>

    @Insert
    suspend fun insert(item: DownloadEntity): Long

    @Update
    suspend fun update(item: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM downloads WHERE status IN ('COMPLETED', 'FAILED', 'CANCELED')")
    suspend fun deleteFinished()

    @Query("UPDATE downloads SET status = 'PAUSED', error = 'Interrompu : l''application a été fermée' WHERE status IN ('DOWNLOADING', 'QUEUED')")
    suspend fun markInterrupted()
}
