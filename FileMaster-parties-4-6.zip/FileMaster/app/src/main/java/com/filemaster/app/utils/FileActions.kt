package com.filemaster.app.utils

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Actions « système » : ouvrir et partager via FileProvider (aucun contournement des protections Android). */
object FileActions {

    fun mimeType(file: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"

    private fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    fun open(context: Context, file: File) {
        if (file.extension.equals("apk", ignoreCase = true)) {
            Toast.makeText(context, "L'installation d'APK n'est pas encore prise en charge.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriFor(context, file), mimeType(file))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Aucune application ne peut ouvrir ce fichier.", Toast.LENGTH_SHORT).show()
        } catch (e: IllegalArgumentException) {
            Toast.makeText(context, "Ce fichier ne peut pas être ouvert.", Toast.LENGTH_SHORT).show()
        }
    }

    fun share(context: Context, files: List<File>) {
        val shareable = files.filter { it.isFile }
        if (shareable.isEmpty()) {
            Toast.makeText(context, "Seuls les fichiers peuvent être partagés, pas les dossiers.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uris = ArrayList(shareable.map { uriFor(context, it) })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeType(shareable.first())
                    putExtra(Intent.EXTRA_STREAM, uris.first())
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(intent, "Partager"))
            if (shareable.size < files.size) {
                Toast.makeText(context, "Les dossiers ont été ignorés.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Partage impossible.", Toast.LENGTH_SHORT).show()
        }
    }
}
