package com.filemaster.app.features.files

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.model.LayoutMode
import com.filemaster.app.domain.model.OperationResult
import com.filemaster.app.domain.model.OperationType
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.SortField
import com.filemaster.app.domain.model.SortOption
import com.filemaster.app.utils.FileActions
import com.filemaster.app.utils.FileSorting
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

class FilesViewModel(
    private val c: AppContainer,
    handle: SavedStateHandle
) : ViewModel() {

    val rootPath: String = c.storageRepository.root().absolutePath

    private val initialPath: String? = handle.get<String>("path")?.takeIf { it.isNotBlank() }
    private val initialSearch: Boolean = handle.get<Boolean>("search") ?: false

    private val _state = MutableStateFlow(FilesUiState(currentPath = initialPath ?: rootPath))
    val state: StateFlow<FilesUiState> = _state.asStateFlow()

    private var allItems: List<FileItem> = emptyList()
    private val backStack = ArrayDeque<String>()
    private val forwardStack = ArrayDeque<String>()
    private var started = false
    private var loadJob: Job? = null
    private var searchJob: Job? = null
    private var propertiesJob: Job? = null

    init {
        viewModelScope.launch {
            c.settingsRepository.settings.collect { s ->
                if (!started) {
                    started = true
                    _state.update {
                        it.copy(
                            settings = s,
                            currentPath = initialPath ?: s.startFolder.ifBlank { rootPath },
                            sort = SortOption(s.sortField, s.sortAscending),
                            showHidden = s.showHidden,
                            searchActive = initialSearch
                        )
                    }
                    reload()
                } else {
                    _state.update { it.copy(settings = s) }
                }
            }
        }
        viewModelScope.launch {
            c.favoritesRepository.observePaths().collect { paths ->
                _state.update { it.copy(favorites = paths.toSet()) }
            }
        }
    }

    // ------------------------------------------------------------ chargement

    fun reload() {
        loadJob?.cancel()
        val path = _state.value.currentPath
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            c.fileRepository.list(File(path), _state.value.showHidden).fold(
                onSuccess = { list ->
                    allItems = list
                    val paths = list.mapTo(HashSet()) { it.path }
                    _state.update { it.copy(loading = false, selected = it.selected.filter { p -> p in paths }.toSet()) }
                    applyView()
                },
                onFailure = { e ->
                    allItems = emptyList()
                    _state.update { it.copy(loading = false, error = e.message ?: "Erreur inconnue") }
                    applyView()
                }
            )
        }
    }

    private fun applyView() {
        _state.update { s ->
            val filtered = s.extensionFilter
                ?.let { ext -> allItems.filter { it.isDirectory || it.extension == ext } }
                ?: allItems
            s.copy(
                items = filtered.sortedWith(FileSorting.comparator(s.sort)),
                availableExtensions = allItems.asSequence()
                    .filter { !it.isDirectory && it.extension.isNotEmpty() }
                    .map { it.extension }.distinct().sorted().take(15).toList()
            )
        }
    }

    // ------------------------------------------------------------ navigation

    fun navigateTo(path: String) {
        val current = _state.value.currentPath
        if (path == current) return
        backStack.addLast(current)
        forwardStack.clear()
        setPath(path)
    }

    fun goBack() {
        if (backStack.isEmpty()) return
        forwardStack.addLast(_state.value.currentPath)
        setPath(backStack.removeLast())
    }

    fun goForward() {
        if (forwardStack.isEmpty()) return
        backStack.addLast(_state.value.currentPath)
        setPath(forwardStack.removeLast())
    }

    /** Remonte au dossier parent. Retourne false si on est déjà à la racine. */
    fun goUp(): Boolean {
        val current = _state.value.currentPath
        val parent = File(current).parentFile
        if (current == rootPath || parent == null) return false
        navigateTo(parent.absolutePath)
        return true
    }

    private fun setPath(path: String) {
        searchJob?.cancel()
        _state.update {
            it.copy(
                currentPath = path,
                selected = emptySet(),
                extensionFilter = null,
                searchActive = false,
                query = "",
                searchResults = null,
                searching = false,
                canGoBack = backStack.isNotEmpty(),
                canGoForward = forwardStack.isNotEmpty()
            )
        }
        reload()
    }

    // ------------------------------------------------------------ affichage

    fun setSort(field: SortField) {
        _state.update {
            val asc = if (it.sort.field == field) !it.sort.ascending else true
            it.copy(sort = SortOption(field, asc))
        }
        applyView()
    }

    fun toggleHidden() {
        _state.update { it.copy(showHidden = !it.showHidden) }
        reload()
    }

    fun setExtensionFilter(extension: String?) {
        _state.update { it.copy(extensionFilter = extension) }
        applyView()
    }

    fun toggleLayout() {
        val next = if (_state.value.settings.layoutMode == LayoutMode.LIST) LayoutMode.GRID else LayoutMode.LIST
        viewModelScope.launch { c.settingsRepository.setLayoutMode(next) }
    }

    // ------------------------------------------------------------ recherche

    fun setSearchActive(active: Boolean) {
        searchJob?.cancel()
        _state.update { it.copy(searchActive = active, query = "", searchResults = null, searching = false) }
    }

    fun onQueryChange(query: String) {
        _state.update { it.copy(query = query) }
        searchJob?.cancel()
        if (query.isBlank()) {
            _state.update { it.copy(searchResults = null, searching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(300)
            _state.update { it.copy(searching = true) }
            val s = _state.value
            val results = c.fileRepository.search(File(s.currentPath), query, s.showHidden)
            _state.update { it.copy(searchResults = results.sortedWith(FileSorting.comparator(it.sort)), searching = false) }
        }
    }

    // ------------------------------------------------------------ sélection

    fun toggleSelect(path: String) {
        _state.update { it.copy(selected = if (path in it.selected) it.selected - path else it.selected + path) }
    }

    fun selectAll() {
        _state.update { s -> s.copy(selected = s.displayedItems().map { it.path }.toSet()) }
    }

    fun clearSelection() {
        _state.update { it.copy(selected = emptySet()) }
    }

    // ------------------------------------------------------------ opérations

    private fun runOp(block: suspend () -> Unit) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                block()
            } finally {
                _state.update { it.copy(busy = false) }
                reload()
            }
        }
    }

    private fun toast(text: String) {
        _state.update { it.copy(message = text) }
    }

    fun messageShown() {
        _state.update { it.copy(message = null) }
    }

    fun createFolder(name: String) = runOp {
        val parent = File(_state.value.currentPath)
        c.fileRepository.createFolder(parent, name).fold(
            onSuccess = {
                c.historyRepository.log(OperationType.CREATE_FOLDER, "Dossier « ${it.name} » créé", true)
                toast("Dossier créé")
            },
            onFailure = { toast(it.message ?: "Échec de la création du dossier") }
        )
    }

    fun rename(path: String, newName: String) = runOp {
        val file = File(path)
        c.fileRepository.rename(file, newName).fold(
            onSuccess = { renamed ->
                if (renamed.absolutePath != path) {
                    c.favoritesRepository.rename(path, renamed.absolutePath)
                    c.historyRepository.log(OperationType.RENAME, "« ${file.name} » renommé en « ${renamed.name} »", true)
                    toast("Renommé")
                }
            },
            onFailure = { toast(it.message ?: "Échec du renommage") }
        )
    }

    fun delete(paths: List<String>) = runOp {
        val result = c.fileRepository.delete(paths.map(::File))
        val gone = paths.filter { !File(it).exists() }
        if (gone.isNotEmpty()) {
            c.favoritesRepository.remove(gone)
            c.recentRepository.remove(gone)
        }
        report(OperationType.DELETE, "Suppression", result)
        clearSelection()
    }

    fun copyToClipboard(move: Boolean) {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(clipboard = Clipboard(paths, move), selected = emptySet()) }
    }

    fun cancelClipboard() {
        _state.update { it.copy(clipboard = null) }
    }

    fun paste() {
        val clip = _state.value.clipboard ?: return
        val target = File(_state.value.currentPath)
        runOp {
            val files = clip.paths.map(::File)
            val result = if (clip.move) c.fileRepository.move(files, target) else c.fileRepository.copy(files, target)
            val label = if (clip.move) "Déplacement vers" else "Copie vers"
            report(
                if (clip.move) OperationType.MOVE else OperationType.COPY,
                "$label ${target.name.ifEmpty { "/" }}",
                result
            )
            if (clip.move && result.successCount > 0) {
                _state.update { it.copy(clipboard = null) }
            }
        }
    }

    private suspend fun report(type: OperationType, title: String, result: OperationResult) {
        val description = buildString {
            append("$title : ${result.successCount} élément(s)")
            if (result.errors.isNotEmpty()) append(", ${result.errors.size} échec(s)")
        }
        c.historyRepository.log(type, description, result.errors.isEmpty())
        toast(if (result.errors.isEmpty()) description else "$description — ${result.errors.first()}")
    }

    fun toggleFavorites() {
        val s = _state.value
        val paths = s.selected.toList()
        if (paths.isEmpty()) return
        val allFavorite = paths.all { it in s.favorites }
        viewModelScope.launch {
            if (allFavorite) c.favoritesRepository.remove(paths) else c.favoritesRepository.add(paths)
            toast(if (allFavorite) "Retiré des favoris" else "Ajouté aux favoris")
            clearSelection()
        }
    }

    fun onFileOpened(path: String) {
        viewModelScope.launch { c.recentRepository.record(path) }
    }

    // ------------------------------------------------------------ propriétés

    fun showProperties(path: String) {
        propertiesJob?.cancel()
        propertiesJob = viewModelScope.launch {
            val item = c.fileRepository.itemOrNull(path) ?: return@launch
            val file = File(path)
            _state.update {
                it.copy(
                    properties = PropertiesInfo(
                        item = item,
                        sizeBytes = if (item.isDirectory) null else item.size,
                        fileCount = null,
                        canRead = file.canRead(),
                        canWrite = file.canWrite(),
                        mime = if (item.isDirectory) null else FileActions.mimeType(file)
                    )
                )
            }
            if (item.isDirectory) {
                val (size, count) = c.fileRepository.computeSize(file)
                _state.update { s ->
                    val p = s.properties
                    if (p != null && p.item.path == path) s.copy(properties = p.copy(sizeBytes = size, fileCount = count)) else s
                }
            }
        }
    }

    fun dismissProperties() {
        propertiesJob?.cancel()
        _state.update { it.copy(properties = null) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                FilesViewModel(app.container, createSavedStateHandle())
            }
        }
    }
}
