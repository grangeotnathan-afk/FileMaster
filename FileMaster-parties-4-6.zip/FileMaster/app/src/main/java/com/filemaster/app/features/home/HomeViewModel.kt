package com.filemaster.app.features.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.analysis.CategoryRules
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.OperationRecord
import com.filemaster.app.domain.model.ScanStatus
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.domain.model.StandardFolder
import com.filemaster.app.domain.model.StorageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class HomeUiState(
    val loading: Boolean = true,
    val storage: StorageInfo? = null,
    val recentOpened: List<FileItem> = emptyList(),
    val recentDownloads: List<FileItem> = emptyList(),
    val favorites: List<FileItem> = emptyList(),
    val favoriteCount: Int = 0,
    val activity: List<OperationRecord> = emptyList()
)

class HomeViewModel(private val c: AppContainer) : ViewModel() {

    private val refreshTick = MutableStateFlow(0)
    private val downloadsPath = c.storageRepository.pathOf(StandardFolder.DOWNLOADS)

    val settings: StateFlow<AppSettings> = c.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    /** Nombre de fichiers par catégorie, une fois le parcours du stockage terminé (null avant). */
    val categoryCounts: StateFlow<Map<SmartCategory, Int>?> = c.scanRepository.state
        .map { s -> if (s.status == ScanStatus.DONE) CategoryRules.counts(s.files, downloadsPath) else null }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val scanStatus: StateFlow<ScanStatus> = c.scanRepository.state
        .map { it.status }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ScanStatus.IDLE)

    val uiState: StateFlow<HomeUiState> = combine(
        refreshTick,
        c.favoritesRepository.observePaths(),
        c.recentRepository.observePaths(10),
        c.historyRepository.observeRecent(8)
    ) { _, favoritePaths, recentPaths, operations ->
        withContext(Dispatchers.IO) {
            val favorites = favoritePaths.mapNotNull { c.fileRepository.itemOrNull(it) }
            HomeUiState(
                loading = false,
                storage = c.storageRepository.internalStorage(),
                recentOpened = recentPaths.mapNotNull { c.fileRepository.itemOrNull(it) },
                recentDownloads = c.fileRepository.recentFiles(File(downloadsPath), 8),
                favorites = favorites.take(10),
                favoriteCount = favorites.size,
                activity = operations
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    /** Relit les valeurs réelles (stockage, dossiers) — appelé à chaque retour sur l'écran. */
    fun refresh() {
        refreshTick.update { it + 1 }
    }

    /** Lance le parcours du stockage (une seule fois par session, nécessaire aux catégories). */
    fun ensureScan() {
        c.scanRepository.start(c.storageRepository.root())
    }

    fun onFileOpened(path: String) {
        viewModelScope.launch { c.recentRepository.record(path) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                HomeViewModel(app.container)
            }
        }
    }
}
