package com.filemaster.app.features.transfers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.DownloadItem
import com.filemaster.app.domain.model.StandardFolder
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.net.URL

class DownloadsViewModel(private val c: AppContainer) : ViewModel() {

    val downloads: StateFlow<List<DownloadItem>> = c.downloadCoordinator.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val settings: StateFlow<AppSettings> = c.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val rootPath: String = c.storageRepository.root().absolutePath

    fun defaultFolder(): String =
        settings.value.downloadFolder.ifBlank { c.storageRepository.pathOf(StandardFolder.DOWNLOADS) }

    suspend fun subfolders(dir: File): List<File> = c.fileRepository.listSubfolders(dir)

    /** Retourne un message d'erreur si l'adresse ou le dossier sont invalides, sinon null (téléchargement lancé). */
    fun start(rawUrl: String, folder: String): String? {
        var url = rawUrl.trim()
        if (url.isEmpty()) return "Saisissez une adresse."
        if (!url.contains("://")) url = "https://$url"
        val parsed = runCatching { URL(url) }.getOrNull()
        if (parsed == null || (parsed.protocol != "http" && parsed.protocol != "https") || parsed.host.isNullOrBlank()) {
            return "Adresse invalide : seules les adresses http:// et https:// sont acceptées."
        }
        val dir = File(folder)
        if ((!dir.exists() && !dir.mkdirs()) || !dir.canWrite()) {
            return "Le dossier choisi n'est pas accessible en écriture."
        }
        viewModelScope.launch {
            c.settingsRepository.setDownloadFolder(folder)
            c.downloadCoordinator.enqueue(url, dir.absolutePath)
        }
        return null
    }

    fun pause(id: Long) = c.downloadCoordinator.pause(id)
    fun resume(id: Long) = c.downloadCoordinator.resume(id)
    fun cancel(id: Long) = c.downloadCoordinator.cancel(id)
    fun remove(id: Long) = c.downloadCoordinator.remove(id)
    fun clearFinished() = c.downloadCoordinator.clearFinished()

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                DownloadsViewModel(app.container)
            }
        }
    }
}
