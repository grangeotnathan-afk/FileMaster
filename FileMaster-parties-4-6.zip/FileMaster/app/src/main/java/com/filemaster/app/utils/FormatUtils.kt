package com.filemaster.app.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes o"
    val units = arrayOf("Ko", "Mo", "Go", "To")
    var value = bytes.toDouble()
    var index = -1
    do {
        value /= 1024
        index++
    } while (value >= 1024 && index < units.lastIndex)
    val pattern = if (value >= 100) "%.0f %s" else "%.1f %s"
    return String.format(Locale.getDefault(), pattern, value, units[index])
}

fun formatDate(millis: Long): String {
    if (millis <= 0L) return "—"
    return SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(millis))
}

fun elementsLabel(count: Int): String = if (count <= 1) "$count élément" else "$count éléments"
