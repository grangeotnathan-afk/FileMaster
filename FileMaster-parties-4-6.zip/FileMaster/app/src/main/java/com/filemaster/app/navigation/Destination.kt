package com.filemaster.app.navigation

import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Destination(val route: String, val label: String, val icon: ImageVector) {
    object Home : Destination("home", "Accueil", Icons.Rounded.Home)

    object Files : Destination("files", "Fichiers", Icons.Rounded.FolderOpen) {
        const val ARG_PATH = "path"
        const val ARG_SEARCH = "search"
        const val PATTERN = "files?path={path}&search={search}"

        fun create(path: String? = null, search: Boolean = false): String {
            val p = if (path != null) "path=${Uri.encode(path)}&" else ""
            return "files?${p}search=$search"
        }
    }

    object Analysis : Destination("analysis", "Analyse", Icons.Rounded.PieChart)
    object Transfers : Destination("transfers", "Transferts", Icons.Rounded.SwapHoriz)
    object Settings : Destination("settings", "Paramètres", Icons.Rounded.Settings)
}

val bottomDestinations: List<Destination> = listOf(
    Destination.Home,
    Destination.Files,
    Destination.Analysis,
    Destination.Transfers,
    Destination.Settings
)

object CategoryRoute {
    const val PATTERN = "category/{id}"
    fun create(category: com.filemaster.app.domain.model.SmartCategory) = "category/${category.name}"
}
