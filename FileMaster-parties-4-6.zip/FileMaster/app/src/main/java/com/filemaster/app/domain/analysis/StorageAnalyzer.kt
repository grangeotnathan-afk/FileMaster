package com.filemaster.app.domain.analysis

import com.filemaster.app.domain.model.CategoryStat
import com.filemaster.app.domain.model.FileCategory
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.FolderStat
import com.filemaster.app.domain.model.JunkItem

/** Calculs purs (sans accès au système) à partir du résultat d'un parcours. */
object StorageAnalyzer {
    private const val DAY_MS = 86_400_000L

    private val tempExtensions = setOf("tmp", "temp", "bak", "old", "crdownload", "part", "partial", "dmp", "chk")

    fun categoryStats(files: List<FileItem>): List<CategoryStat> =
        files.groupBy { it.category }
            .map { (category, list) -> CategoryStat(category, list.size, list.sumOf { it.size }) }
            .sortedByDescending { it.size }

    fun largest(files: List<FileItem>, limit: Int = 50): List<FileItem> =
        files.sortedByDescending { it.size }.take(limit)

    /** Taille cumulée (sous-dossiers inclus) des dossiers situés à 1..maxDepth niveaux sous la racine. */
    fun folderStats(dirSizes: Map<String, Long>, root: String, maxDepth: Int = 2, limit: Int = 25): List<FolderStat> {
        val totals = HashMap<String, Long>()
        for ((dir, size) in dirSizes) {
            if (size == 0L) continue
            var p: String = dir
            while (p.length >= root.length) {
                totals[p] = (totals[p] ?: 0L) + size
                if (p == root) break
                p = p.substringBeforeLast('/', "")
                if (p.isEmpty()) break
            }
        }
        return totals.entries.asSequence()
            .filter { (path, _) ->
                path != root && path.startsWith("$root/") &&
                    path.removePrefix(root).count { it == '/' } in 1..maxDepth
            }
            .map { FolderStat(it.key, it.value) }
            .sortedByDescending { it.size }
            .take(limit)
            .toList()
    }

    /** Fichiers non MODIFIÉS depuis le seuil (Android ne fournit pas de date de dernière ouverture fiable). */
    fun oldFiles(files: List<FileItem>, now: Long, olderThanDays: Int, limit: Int = 200): List<FileItem> {
        val limitDate = now - olderThanDays * DAY_MS
        return files.asSequence()
            .filter { it.lastModified in 1 until limitDate }
            .sortedByDescending { it.size }
            .take(limit)
            .toList()
    }

    /** Détection par règles simples (nom, extension, dossier) : à vérifier avant toute suppression. */
    fun junk(files: List<FileItem>, limit: Int = 500): List<JunkItem> {
        val out = ArrayList<JunkItem>()
        for (f in files) {
            val reason = when {
                f.size == 0L && f.name != ".nomedia" -> "Fichier vide (0 octet)"
                f.extension in tempExtensions -> "Fichier temporaire ou de sauvegarde"
                f.extension == "log" -> "Journal (.log)"
                f.path.contains("/.thumbnails/") || f.path.contains("/.cache/") -> "Cache de miniatures ou d'application"
                f.category == FileCategory.APK && f.path.contains("/Download/") -> "Installateur APK dans Téléchargements"
                else -> null
            }
            if (reason != null) out += JunkItem(f, reason)
        }
        return out.sortedByDescending { it.file.size }.take(limit)
    }
}
