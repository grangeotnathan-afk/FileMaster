package com.filemaster.app.repository

import com.filemaster.app.database.RecentDao
import com.filemaster.app.database.RecentFileEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RecentRepository(private val dao: RecentDao) {
    fun observePaths(limit: Int): Flow<List<String>> = dao.observeRecent(limit).map { list -> list.map { it.path } }

    suspend fun record(path: String) {
        dao.insert(RecentFileEntity(path, System.currentTimeMillis()))
        dao.trim(100)
    }

    suspend fun remove(paths: List<String>) = dao.deleteAll(paths)
}
