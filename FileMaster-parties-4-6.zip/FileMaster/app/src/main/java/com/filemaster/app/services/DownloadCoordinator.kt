package com.filemaster.app.services

import android.content.Context
import android.os.SystemClock
import com.filemaster.app.database.DownloadDao
import com.filemaster.app.database.DownloadEntity
import com.filemaster.app.domain.model.DownloadItem
import com.filemaster.app.domain.model.DownloadStatus
import com.filemaster.app.domain.model.OperationType
import com.filemaster.app.repository.HistoryRepository
import com.filemaster.app.utils.uniqueFile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.SSLException

data class LiveProgress(val downloaded: Long, val total: Long, val speed: Long)
data class ActiveSummary(val count: Int, val downloaded: Long, val total: Long, val speed: Long)

/**
 * Orchestre les téléchargements : file d'attente (3 en parallèle), pause/reprise/annulation,
 * persistance dans Room. Le DownloadService ne sert qu'à garder le processus actif en arrière-plan.
 */
class DownloadCoordinator(
    private val appContext: Context,
    private val dao: DownloadDao,
    private val history: HistoryRepository,
    private val scope: CoroutineScope
) {
    private enum class StopReason { PAUSE, CANCEL }

    private val downloader = HttpDownloader()
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val stopReasons = ConcurrentHashMap<Long, StopReason>()
    private val semaphore = Semaphore(MAX_PARALLEL)
    private val live = MutableStateFlow<Map<Long, LiveProgress>>(emptyMap())
    private val activeIds = MutableStateFlow<Set<Long>>(emptySet())

    init {
        // Après une fermeture brutale de l'app, les téléchargements « en cours » sont en réalité interrompus.
        scope.launch { dao.markInterrupted() }
    }

    val activeSummary: Flow<ActiveSummary> = combine(activeIds, live) { ids, progress ->
        val active = progress.filterKeys { it in ids }.values
        ActiveSummary(
            count = ids.size,
            downloaded = active.sumOf { it.downloaded },
            total = active.filter { it.total > 0 }.sumOf { it.total },
            speed = active.sumOf { it.speed }
        )
    }

    fun observe(): Flow<List<DownloadItem>> = combine(dao.observeAll(), live) { list, progress ->
        list.map { e ->
            val l = progress[e.id]
            DownloadItem(
                id = e.id,
                url = e.url,
                fileName = e.fileName,
                destDir = e.destDir,
                status = DownloadStatus.fromName(e.status),
                downloadedBytes = l?.downloaded ?: e.downloadedBytes,
                totalBytes = e.totalBytes,
                speedBytesPerSec = l?.speed ?: 0L,
                error = e.error,
                acceptsRanges = e.acceptsRanges,
                createdAt = e.createdAt,
                finishedAt = e.finishedAt
            )
        }
    }

    suspend fun enqueue(url: String, destDir: String): Long {
        val id = dao.insert(
            DownloadEntity(
                url = url,
                fileName = HttpDownloader.fileNameFromUrl(url),
                destDir = destDir,
                totalBytes = -1,
                downloadedBytes = 0,
                status = DownloadStatus.QUEUED.name,
                error = null,
                acceptsRanges = false,
                createdAt = System.currentTimeMillis(),
                finishedAt = null
            )
        )
        start(id)
        return id
    }

    fun pause(id: Long) {
        stopReasons[id] = StopReason.PAUSE
        jobs[id]?.cancel()
    }

    fun cancel(id: Long) {
        stopReasons[id] = StopReason.CANCEL
        val job = jobs[id]
        if (job != null && job.isActive) {
            job.cancel()
        } else {
            scope.launch { applyStop(id) }
        }
    }

    /** Reprend (depuis l'octet déjà reçu si le serveur le permet) ou relance un téléchargement. */
    fun resume(id: Long) {
        scope.launch {
            val e = dao.get(id) ?: return@launch
            val status = DownloadStatus.fromName(e.status)
            if (status == DownloadStatus.PAUSED || status == DownloadStatus.FAILED || status == DownloadStatus.CANCELED) {
                dao.update(e.copy(status = DownloadStatus.QUEUED.name, error = null, finishedAt = null))
                start(id)
            }
        }
    }

    fun remove(id: Long) {
        scope.launch {
            val e = dao.get(id) ?: return@launch
            if (jobs[id]?.isActive == true) return@launch
            partFile(e).delete()
            dao.delete(id)
        }
    }

    fun clearFinished() {
        scope.launch {
            dao.getFinished().forEach { partFile(it).delete() }
            dao.deleteFinished()
        }
    }

    private fun start(id: Long) {
        if (jobs[id]?.isActive == true) return
        stopReasons.remove(id)
        activeIds.update { it + id }
        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                semaphore.withPermit { runDownload(id) }
            } catch (e: CancellationException) {
                withContext(NonCancellable) { applyStop(id) }
                throw e
            }
        }
        jobs[id] = job
        job.invokeOnCompletion {
            jobs.remove(id, job)
            activeIds.update { it - id }
            live.update { it - id }
        }
        job.start()
        DownloadService.start(appContext)
    }

    private suspend fun applyStop(id: Long) {
        val e = dao.get(id) ?: return
        val status = DownloadStatus.fromName(e.status)
        if (status == DownloadStatus.COMPLETED) return
        val part = partFile(e)
        if (stopReasons.remove(id) == StopReason.CANCEL) {
            part.delete()
            dao.update(e.copy(status = DownloadStatus.CANCELED.name, downloadedBytes = 0, error = null, finishedAt = System.currentTimeMillis()))
        } else {
            val received = if (part.exists()) part.length() else e.downloadedBytes
            dao.update(e.copy(status = DownloadStatus.PAUSED.name, downloadedBytes = received))
        }
    }

    private suspend fun runDownload(id: Long) {
        var e = dao.get(id) ?: return
        val part = partFile(e)
        e = e.copy(status = DownloadStatus.DOWNLOADING.name, error = null)
        dao.update(e)

        val startAt = if (part.exists()) part.length() else 0L
        var lastBytes = startAt
        var lastSpeedAt = SystemClock.elapsedRealtime()
        var lastPersist = lastSpeedAt
        var speed = 0L

        try {
            val downloaded = downloader.download(
                url = e.url,
                part = part,
                startAt = startAt,
                onMeta = { meta ->
                    e = e.copy(
                        fileName = meta.fileName ?: e.fileName,
                        totalBytes = meta.total,
                        acceptsRanges = meta.acceptsRanges
                    )
                    dao.update(e)
                },
                onProgress = { bytes ->
                    val now = SystemClock.elapsedRealtime()
                    if (bytes < lastBytes) lastBytes = bytes // le serveur a relancé depuis zéro
                    if (now - lastSpeedAt >= 500) {
                        val instant = (bytes - lastBytes) * 1000 / (now - lastSpeedAt)
                        speed = if (speed == 0L) instant else (speed * 0.6 + instant * 0.4).toLong()
                        lastSpeedAt = now
                        lastBytes = bytes
                        live.update { it + (id to LiveProgress(bytes, e.totalBytes, speed)) }
                    }
                    if (now - lastPersist >= 1000) {
                        lastPersist = now
                        dao.update(e.copy(downloadedBytes = bytes))
                    }
                }
            )
            if (e.totalBytes > 0 && downloaded != e.totalBytes) {
                throw IOException("Téléchargement incomplet ($downloaded sur ${e.totalBytes} octets)")
            }
            val target = uniqueFile(File(e.destDir), HttpDownloader.sanitizeName(e.fileName).ifBlank { "telechargement" })
            if (!part.renameTo(target)) throw IOException("Impossible d'enregistrer le fichier dans le dossier choisi")
            dao.update(
                e.copy(
                    fileName = target.name,
                    status = DownloadStatus.COMPLETED.name,
                    downloadedBytes = target.length(),
                    totalBytes = target.length(),
                    error = null,
                    finishedAt = System.currentTimeMillis()
                )
            )
            history.log(OperationType.DOWNLOAD, "Téléchargé : ${target.name}", true)
        } catch (ex: CancellationException) {
            throw ex
        } catch (ex: Exception) {
            // Une coupure volontaire (pause/annulation) provoque aussi une IOException : ce n'est pas un échec.
            if (!currentCoroutineContext().isActive) throw CancellationException("Arrêté")
            val received = if (part.exists()) part.length() else 0L
            dao.update(
                e.copy(
                    status = DownloadStatus.FAILED.name,
                    downloadedBytes = received,
                    error = userMessage(ex),
                    finishedAt = System.currentTimeMillis()
                )
            )
            history.log(OperationType.DOWNLOAD, "Échec du téléchargement de ${e.fileName}", false)
        }
    }

    private fun partFile(e: DownloadEntity) = File(e.destDir, ".filemaster-${e.id}.part")

    private fun userMessage(e: Exception): String = when (e) {
        is UnknownHostException -> "Serveur introuvable : vérifiez l'adresse et la connexion Internet"
        is SocketTimeoutException -> "Délai dépassé : le serveur ne répond pas"
        is SSLException -> "Connexion sécurisée impossible (certificat ou protocole)"
        else -> e.message ?: "Erreur inconnue"
    }

    private companion object {
        const val MAX_PARALLEL = 3
    }
}
