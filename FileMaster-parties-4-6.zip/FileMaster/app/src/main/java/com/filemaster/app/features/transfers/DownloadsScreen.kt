package com.filemaster.app.features.transfers

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemaster.app.domain.model.DownloadItem
import com.filemaster.app.domain.model.DownloadStatus
import com.filemaster.app.ui.components.FolderPickerDialog
import com.filemaster.app.utils.FileActions
import com.filemaster.app.utils.formatDate
import com.filemaster.app.utils.formatSize
import java.io.File

@Composable
fun DownloadsScreen(viewModel: DownloadsViewModel = viewModel(factory = DownloadsViewModel.Factory)) {
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showNew by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNew = true },
                icon = { Icon(Icons.Rounded.Download, contentDescription = null) },
                text = { Text("Télécharger") }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (downloads.any { it.status == DownloadStatus.COMPLETED || it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELED }) {
                TextButton(onClick = { viewModel.clearFinished() }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text("Effacer l'historique terminé")
                }
            }
            if (downloads.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Aucun téléchargement", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Collez l'adresse http(s) d'un fichier. Les téléchargements continuent en arrière-plan.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(downloads, key = { it.id }) { item ->
                        DownloadCard(
                            item = item,
                            onPause = { viewModel.pause(item.id) },
                            onResume = { viewModel.resume(item.id) },
                            onCancel = { viewModel.cancel(item.id) },
                            onRemove = { viewModel.remove(item.id) },
                            onOpen = {
                                val file = File(item.destDir, item.fileName)
                                if (file.exists()) FileActions.open(context, file)
                                else Toast.makeText(context, "Fichier introuvable (déplacé ou supprimé).", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }

    if (showNew) {
        NewDownloadDialog(
            viewModel = viewModel,
            onDismiss = { showNew = false },
            onStarted = {
                showNew = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        )
    }
}

@Composable
private fun NewDownloadDialog(viewModel: DownloadsViewModel, onDismiss: () -> Unit, onStarted: () -> Unit) {
    var url by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf(viewModel.defaultFolder()) }
    var error by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Nouveau téléchargement") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; error = null },
                    label = { Text("Adresse (http:// ou https://)") },
                    isError = error != null,
                    supportingText = error?.let { { Text(it) } },
                    modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = { clipboard.getText()?.text?.let { url = it; error = null } }) {
                    Text("Coller depuis le presse-papiers")
                }
                Text("Dossier de destination", style = MaterialTheme.typography.labelMedium)
                OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "…" + folder.removePrefix(viewModel.rootPath).ifEmpty { "/" },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val problem = viewModel.start(url, folder)
                if (problem == null) onStarted() else error = problem
            }) { Text("Télécharger") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )

    if (picking) {
        FolderPickerDialog(
            startPath = folder,
            rootPath = viewModel.rootPath,
            loadSubfolders = { viewModel.subfolders(it) },
            onPick = { folder = it; picking = false },
            onDismiss = { picking = false }
        )
    }
}

@Composable
private fun DownloadCard(
    item: DownloadItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRemove: () -> Unit,
    onOpen: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.fileName, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        item.url,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(8.dp))
                when (item.status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED -> {
                        if (item.status == DownloadStatus.DOWNLOADING) {
                            IconButton(onClick = onPause) { Icon(Icons.Rounded.Pause, contentDescription = "Mettre en pause") }
                        }
                        IconButton(onClick = onCancel) { Icon(Icons.Rounded.Close, contentDescription = "Annuler") }
                    }
                    DownloadStatus.PAUSED, DownloadStatus.FAILED -> {
                        IconButton(onClick = onResume) { Icon(Icons.Rounded.PlayArrow, contentDescription = "Reprendre") }
                        IconButton(onClick = onCancel) { Icon(Icons.Rounded.Close, contentDescription = "Annuler") }
                    }
                    DownloadStatus.CANCELED -> {
                        IconButton(onClick = onResume) { Icon(Icons.Rounded.PlayArrow, contentDescription = "Relancer") }
                        IconButton(onClick = onRemove) { Icon(Icons.Rounded.Delete, contentDescription = "Retirer de l'historique") }
                    }
                    DownloadStatus.COMPLETED -> {
                        IconButton(onClick = onOpen) { Icon(Icons.Rounded.OpenInNew, contentDescription = "Ouvrir") }
                        IconButton(onClick = onRemove) { Icon(Icons.Rounded.Delete, contentDescription = "Retirer de l'historique") }
                    }
                }
            }

            val known = item.totalBytes > 0
            if (item.status == DownloadStatus.DOWNLOADING || item.status == DownloadStatus.PAUSED || item.status == DownloadStatus.QUEUED) {
                if (known) {
                    LinearProgressIndicator(
                        progress = { (item.downloadedBytes.toFloat() / item.totalBytes).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (item.status == DownloadStatus.DOWNLOADING) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }

            val received = formatSize(item.downloadedBytes) + " / " + if (known) formatSize(item.totalBytes) else "taille inconnue"
            val line = when (item.status) {
                DownloadStatus.QUEUED -> "En attente"
                DownloadStatus.DOWNLOADING -> buildString {
                    append(received)
                    if (item.speedBytesPerSec > 0) {
                        append(" • ${formatSize(item.speedBytesPerSec)}/s")
                        if (known) {
                            val seconds = (item.totalBytes - item.downloadedBytes) / item.speedBytesPerSec
                            append(" • ${formatEta(seconds)}")
                        }
                    }
                }
                DownloadStatus.PAUSED -> buildString {
                    append("En pause • $received")
                    if (!item.acceptsRanges && item.downloadedBytes > 0) append(" • le serveur ne permet pas de reprendre : redémarrage depuis le début")
                    item.error?.let { append(" • $it") }
                }
                DownloadStatus.FAILED -> item.error ?: "Échec"
                DownloadStatus.CANCELED -> "Annulé"
                DownloadStatus.COMPLETED -> "Terminé • ${formatSize(item.downloadedBytes)}" + (item.finishedAt?.let { " • ${formatDate(it)}" } ?: "")
            }
            Text(
                line,
                style = MaterialTheme.typography.bodySmall,
                color = if (item.status == DownloadStatus.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun formatEta(seconds: Long): String = when {
    seconds < 60 -> "$seconds s restantes"
    seconds < 3600 -> "${seconds / 60} min restantes"
    else -> "${seconds / 3600} h ${(seconds % 3600) / 60} min restantes"
}
