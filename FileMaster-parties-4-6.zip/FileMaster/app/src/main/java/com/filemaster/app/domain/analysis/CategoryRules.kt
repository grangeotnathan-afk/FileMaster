package com.filemaster.app.domain.analysis

import com.filemaster.app.domain.model.FileCategory
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.SmartCategory
import java.util.EnumMap

object CategoryRules {
    const val LARGE_THRESHOLD_BYTES = 100L * 1024 * 1024
    const val RECENT_DAYS = 7
    private const val DAY_MS = 86_400_000L

    fun filter(
        files: List<FileItem>,
        category: SmartCategory,
        downloadsPath: String,
        now: Long = System.currentTimeMillis()
    ): List<FileItem> = when (category) {
        SmartCategory.IMAGES -> byFileCategory(files, FileCategory.IMAGES)
        SmartCategory.VIDEOS -> byFileCategory(files, FileCategory.VIDEOS)
        SmartCategory.AUDIO -> byFileCategory(files, FileCategory.AUDIO)
        SmartCategory.DOCUMENTS -> byFileCategory(files, FileCategory.DOCUMENTS)
        SmartCategory.APK -> byFileCategory(files, FileCategory.APK)
        SmartCategory.ARCHIVES -> byFileCategory(files, FileCategory.ARCHIVES)
        SmartCategory.DOWNLOADS -> files.filter { it.path.startsWith("$downloadsPath/") }.sortedByDescending { it.lastModified }
        SmartCategory.LARGE -> files.filter { it.size >= LARGE_THRESHOLD_BYTES }.sortedByDescending { it.size }
        SmartCategory.RECENT -> {
            val limit = now - RECENT_DAYS * DAY_MS
            files.filter { it.lastModified >= limit }.sortedByDescending { it.lastModified }
        }
        SmartCategory.FAVORITES -> emptyList() // fourni par la base de données, pas par le parcours
    }

    /** Compte les fichiers de chaque catégorie en un seul passage. */
    fun counts(files: List<FileItem>, downloadsPath: String, now: Long = System.currentTimeMillis()): Map<SmartCategory, Int> {
        val result = EnumMap<SmartCategory, Int>(SmartCategory::class.java)
        val recentLimit = now - RECENT_DAYS * DAY_MS
        val downloads = "$downloadsPath/"
        fun inc(c: SmartCategory) { result[c] = (result[c] ?: 0) + 1 }
        for (f in files) {
            when (f.category) {
                FileCategory.IMAGES -> inc(SmartCategory.IMAGES)
                FileCategory.VIDEOS -> inc(SmartCategory.VIDEOS)
                FileCategory.AUDIO -> inc(SmartCategory.AUDIO)
                FileCategory.DOCUMENTS -> inc(SmartCategory.DOCUMENTS)
                FileCategory.APK -> inc(SmartCategory.APK)
                FileCategory.ARCHIVES -> inc(SmartCategory.ARCHIVES)
                FileCategory.OTHER -> Unit
            }
            if (f.path.startsWith(downloads)) inc(SmartCategory.DOWNLOADS)
            if (f.size >= LARGE_THRESHOLD_BYTES) inc(SmartCategory.LARGE)
            if (f.lastModified >= recentLimit) inc(SmartCategory.RECENT)
        }
        return result
    }

    private fun byFileCategory(files: List<FileItem>, category: FileCategory): List<FileItem> =
        files.filter { it.category == category }.sortedByDescending { it.lastModified }
}
