package com.filemaster.app.features.transfers

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.filemaster.app.features.placeholder.PlaceholderScreen

/** Onglet « Transferts » : téléchargements HTTP(S) (partie 6) et transferts Wi-Fi locaux (partie 9). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransfersScreen() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Transferts",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp)
        )
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Téléchargements") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Wi-Fi local") })
        }
        when (tab) {
            0 -> DownloadsScreen()
            else -> PlaceholderScreen(
                title = "Transferts Wi-Fi",
                part = 9,
                description = "Envoi et réception entre deux appareils du même réseau, avec QR code et vérification d'intégrité."
            )
        }
    }
}
