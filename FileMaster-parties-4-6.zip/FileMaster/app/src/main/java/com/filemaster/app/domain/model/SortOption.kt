package com.filemaster.app.domain.model

enum class SortField(val label: String) {
    NAME("Nom"),
    SIZE("Taille"),
    DATE("Date"),
    TYPE("Type")
}

data class SortOption(
    val field: SortField = SortField.NAME,
    val ascending: Boolean = true
)
