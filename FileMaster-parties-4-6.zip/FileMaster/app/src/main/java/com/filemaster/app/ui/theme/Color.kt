package com.filemaster.app.ui.theme

import androidx.compose.ui.graphics.Color

/** Couleurs principales proposées dans les paramètres. */
val AccentPalette: List<Long> = listOf(
    0xFF6C63FF, 0xFF0984E3, 0xFF00B894, 0xFFE17055,
    0xFFE84393, 0xFFF2A900, 0xFFD63031, 0xFF00CEC9
)

val FolderColor = Color(0xFFFFB84D)
val StarColor = Color(0xFFFFC857)
