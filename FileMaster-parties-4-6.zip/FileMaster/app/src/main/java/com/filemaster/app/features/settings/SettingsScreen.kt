package com.filemaster.app.features.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemaster.app.BuildConfig
import com.filemaster.app.domain.model.ItemSize
import com.filemaster.app.domain.model.LayoutMode
import com.filemaster.app.domain.model.SortField
import com.filemaster.app.domain.model.ThemeMode
import com.filemaster.app.features.permission.StoragePermissionState
import com.filemaster.app.ui.theme.AccentPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    permission: StoragePermissionState,
    viewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)
) {
    val s by viewModel.settings.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Paramètres", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SettingsCard("Apparence") {
            ChoiceSetting(
                "Thème",
                listOf(ThemeMode.SYSTEM to "Système", ThemeMode.DARK to "Sombre", ThemeMode.LIGHT to "Clair"),
                s.themeMode
            ) { viewModel.setThemeMode(it) }
            ColorSetting(s.primaryColor) { viewModel.setPrimaryColor(it) }
        }

        SettingsCard("Explorateur") {
            ChoiceSetting(
                "Disposition",
                listOf(LayoutMode.LIST to "Liste", LayoutMode.GRID to "Grille"),
                s.layoutMode
            ) { viewModel.setLayoutMode(it) }
            ChoiceSetting(
                "Taille des éléments",
                listOf(ItemSize.COMPACT to "Compact", ItemSize.NORMAL to "Normal", ItemSize.LARGE to "Grand"),
                s.itemSize
            ) { viewModel.setItemSize(it) }
            SwitchSetting("Afficher les extensions", "Ex. : photo.jpg au lieu de photo", s.showExtensions) { viewModel.setShowExtensions(it) }
            SwitchSetting("Afficher les fichiers cachés", "Fichiers dont le nom commence par un point", s.showHidden) { viewModel.setShowHidden(it) }
            ChoiceSetting(
                "Tri par défaut",
                SortField.values().map { it to it.label },
                s.sortField
            ) { viewModel.setSortField(it) }
            SwitchSetting("Tri croissant", null, s.sortAscending) { viewModel.setSortAscending(it) }
            ChoiceSetting("Dossier d'ouverture", viewModel.startFolderChoices, s.startFolder) { viewModel.setStartFolder(it) }
        }

        SettingsCard("Autorisations") {
            Text(
                if (permission.granted) "Accès aux fichiers : accordé" else "Accès aux fichiers : non accordé",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "Android protège certains dossiers (ex. Android/data) : ils restent inaccessibles même avec cette autorisation.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!permission.granted) {
                Button(onClick = permission.request) { Text("Autoriser l'accès") }
            }
        }

        SettingsCard("À propos") {
            Text("FileMaster", style = MaterialTheme.typography.titleSmall)
            Text("Version ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Fonctionne hors ligne, sans compte, sans publicité.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> ChoiceSetting(title: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, label) ->
                FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
            }
        }
    }
}

@Composable
private fun SwitchSetting(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ColorSetting(selected: Long, onSelect: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Couleur principale", style = MaterialTheme.typography.bodyMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AccentPalette.forEach { value ->
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(value))
                        .border(
                            width = if (value == selected) 3.dp else 0.dp,
                            color = MaterialTheme.colorScheme.onSurface,
                            shape = CircleShape
                        )
                        .clickable { onSelect(value) },
                    contentAlignment = Alignment.Center
                ) {
                    if (value == selected) Icon(Icons.Rounded.Check, contentDescription = "Sélectionnée", tint = Color.White)
                }
            }
        }
    }
}
