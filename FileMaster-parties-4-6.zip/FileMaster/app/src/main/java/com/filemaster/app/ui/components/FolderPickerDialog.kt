package com.filemaster.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.filemaster.app.ui.theme.FolderColor
import java.io.File

/** Sélecteur de dossier simple (navigation dans les sous-dossiers). */
@Composable
fun FolderPickerDialog(
    startPath: String,
    rootPath: String,
    loadSubfolders: suspend (File) -> List<File>,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var current by remember { mutableStateOf(startPath) }
    var folders by remember { mutableStateOf<List<File>>(emptyList()) }
    LaunchedEffect(current) { folders = loadSubfolders(File(current)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Choisir un dossier") },
        text = {
            Column {
                Text(
                    "Stockage interne" + current.removePrefix(rootPath),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                TextButton(
                    onClick = { File(current).parent?.let { current = it } },
                    enabled = current != rootPath && File(current).parent != null
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Dossier parent")
                }
                if (folders.isEmpty()) {
                    Text(
                        "Aucun sous-dossier",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(folders, key = { it.path }) { folder ->
                        Row(
                            Modifier.fillMaxWidth().clickable { current = folder.absolutePath }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Folder, contentDescription = null, tint = FolderColor)
                            Spacer(Modifier.width(12.dp))
                            Text(folder.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(current) }) { Text("Choisir ce dossier") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
