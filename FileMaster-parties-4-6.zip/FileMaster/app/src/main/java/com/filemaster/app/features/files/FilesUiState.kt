package com.filemaster.app.features.files

import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.SortOption

data class Clipboard(val paths: List<String>, val move: Boolean)

data class PropertiesInfo(
    val item: FileItem,
    /** null tant que la taille d'un dossier est en cours de calcul. */
    val sizeBytes: Long?,
    val fileCount: Int?,
    val canRead: Boolean,
    val canWrite: Boolean,
    val mime: String?
)

data class FilesUiState(
    val currentPath: String,
    val items: List<FileItem> = emptyList(),
    val loading: Boolean = true,
    val busy: Boolean = false,
    val error: String? = null,
    val selected: Set<String> = emptySet(),
    val favorites: Set<String> = emptySet(),
    val searchActive: Boolean = false,
    val query: String = "",
    val searchResults: List<FileItem>? = null,
    val searching: Boolean = false,
    val sort: SortOption = SortOption(),
    val showHidden: Boolean = false,
    val extensionFilter: String? = null,
    val availableExtensions: List<String> = emptyList(),
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val clipboard: Clipboard? = null,
    val message: String? = null,
    val properties: PropertiesInfo? = null,
    val settings: AppSettings = AppSettings()
) {
    val isSearching: Boolean get() = searchActive && query.isNotBlank()

    fun displayedItems(): List<FileItem> = if (isSearching) searchResults.orEmpty() else items
}
