package com.filemaster.app.repository

import com.filemaster.app.domain.model.FileCategory
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ScanState
import com.filemaster.app.domain.model.ScanStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.nio.file.Files

/**
 * Parcourt réellement le stockage et garde le résultat en mémoire.
 * Les dossiers que le système refuse de lister sont comptés (skippedDirs), jamais inventés.
 */
class ScanRepository(private val scope: CoroutineScope) {

    private val _state = MutableStateFlow(ScanState())
    val state: StateFlow<ScanState> = _state.asStateFlow()
    private var job: Job? = null

    /** Lance un parcours (ignoré s'il est déjà en cours, ou terminé sans `force`). */
    fun start(root: File, force: Boolean = false) {
        if (job?.isActive == true) return
        if (!force && _state.value.status == ScanStatus.DONE) return
        job = scope.launch { scan(root) }
    }

    /** Retire des fichiers supprimés de l'index sans relancer tout le parcours. */
    fun removeFiles(paths: Set<String>) {
        _state.update { s ->
            if (s.status != ScanStatus.DONE) return@update s
            val removed = s.files.filter { it.path in paths }
            if (removed.isEmpty()) return@update s
            val sizes = HashMap(s.dirSizes)
            for (f in removed) {
                val parent = f.path.substringBeforeLast('/')
                sizes[parent] = ((sizes[parent] ?: 0L) - f.size).coerceAtLeast(0L)
            }
            s.copy(files = s.files.filter { it.path !in paths }, dirSizes = sizes, filesFound = s.filesFound - removed.size)
        }
    }

    private suspend fun scan(root: File) {
        // Sans autorisation, la racine n'est pas listable : on n'affiche pas un faux résultat « vide ».
        if (root.listFiles() == null) {
            _state.value = ScanState(status = ScanStatus.IDLE)
            return
        }
        _state.value = ScanState(status = ScanStatus.RUNNING)
        val files = ArrayList<FileItem>()
        val dirSizes = HashMap<String, Long>()
        var skipped = 0
        var lastReported = 0
        val stack = ArrayDeque<File>()
        stack.addLast(root)
        try {
            while (stack.isNotEmpty()) {
                currentCoroutineContext().ensureActive()
                val dir = stack.removeLast()
                val children = dir.listFiles()
                if (children == null) {
                    skipped++
                    continue
                }
                var direct = 0L
                for (f in children) {
                    if (f.isDirectory) {
                        if (!Files.isSymbolicLink(f.toPath())) stack.addLast(f)
                    } else {
                        val ext = f.extension.lowercase()
                        val size = f.length()
                        files += FileItem(
                            path = f.absolutePath,
                            name = f.name,
                            isDirectory = false,
                            size = size,
                            lastModified = f.lastModified(),
                            extension = ext,
                            category = FileCategory.fromExtension(ext),
                            childCount = null,
                            isHidden = f.name.startsWith(".")
                        )
                        direct += size
                    }
                }
                dirSizes[dir.absolutePath] = direct
                if (files.size - lastReported >= 1000) {
                    lastReported = files.size
                    _state.update { it.copy(filesFound = files.size, skippedDirs = skipped) }
                }
            }
            _state.value = ScanState(
                status = ScanStatus.DONE,
                filesFound = files.size,
                skippedDirs = skipped,
                files = files,
                dirSizes = dirSizes,
                finishedAt = System.currentTimeMillis()
            )
        } catch (e: CancellationException) {
            _state.value = ScanState(status = ScanStatus.IDLE)
            throw e
        } catch (e: Exception) {
            _state.value = ScanState(status = ScanStatus.IDLE)
        }
    }
}
