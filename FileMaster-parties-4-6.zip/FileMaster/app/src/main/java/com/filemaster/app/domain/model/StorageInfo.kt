package com.filemaster.app.domain.model

data class StorageInfo(
    val total: Long,
    val used: Long,
    val free: Long
)
