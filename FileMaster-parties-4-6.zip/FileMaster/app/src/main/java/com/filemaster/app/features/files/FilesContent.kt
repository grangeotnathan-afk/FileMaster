package com.filemaster.app.features.files

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FolderOff
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ItemSize
import com.filemaster.app.domain.model.LayoutMode
import com.filemaster.app.ui.components.FileGridCell
import com.filemaster.app.ui.components.FileRow
import com.filemaster.app.utils.buildCrumbs
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesContent(
    state: FilesUiState,
    rootPath: String,
    modifier: Modifier = Modifier,
    onNavigate: (String) -> Unit,
    onItemClick: (FileItem) -> Unit,
    onItemLongClick: (FileItem) -> Unit,
    onExtensionFilter: (String?) -> Unit,
    onRetry: () -> Unit
) {
    val displayed = state.displayedItems()
    val settings = state.settings

    Column(modifier.fillMaxSize()) {
        Breadcrumbs(path = state.currentPath, rootPath = rootPath, onNavigate = onNavigate)

        if (!state.isSearching && state.availableExtensions.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = state.extensionFilter == null, onClick = { onExtensionFilter(null) }, label = { Text("Tout") })
                }
                items(state.availableExtensions, key = { it }) { ext ->
                    FilterChip(
                        selected = state.extensionFilter == ext,
                        onClick = { onExtensionFilter(if (state.extensionFilter == ext) null else ext) },
                        label = { Text(".$ext") }
                    )
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                state.error != null && !state.isSearching -> ErrorState(
                    message = state.error,
                    onRetry = onRetry,
                    onGoRoot = { onNavigate(rootPath) }
                )
                displayed.isEmpty() && (state.loading || state.searching) -> Unit
                displayed.isEmpty() -> EmptyState(if (state.isSearching) "Aucun résultat" else "Dossier vide")
                settings.layoutMode == LayoutMode.GRID -> {
                    val minCell: Dp = when (settings.itemSize) {
                        ItemSize.COMPACT -> 90.dp
                        ItemSize.NORMAL -> 110.dp
                        ItemSize.LARGE -> 140.dp
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minCell),
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(displayed, key = { it.path }) { item ->
                            FileGridCell(
                                item = item,
                                showExtension = settings.showExtensions,
                                itemSize = settings.itemSize,
                                selected = item.path in state.selected,
                                favorite = item.path in state.favorites,
                                onClick = { onItemClick(item) },
                                onLongClick = { onItemLongClick(item) }
                            )
                        }
                    }
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 96.dp)
                ) {
                    items(displayed, key = { it.path }) { item ->
                        FileRow(
                            item = item,
                            showExtension = settings.showExtensions,
                            itemSize = settings.itemSize,
                            selected = item.path in state.selected,
                            favorite = item.path in state.favorites,
                            extraLine = if (state.isSearching) {
                                (File(item.path).parent ?: "/").removePrefix(rootPath).ifEmpty { "/" }
                            } else null,
                            onClick = { onItemClick(item) },
                            onLongClick = { onItemLongClick(item) }
                        )
                    }
                }
            }
            if (state.loading || state.searching || state.busy) {
                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }
}

@Composable
private fun Breadcrumbs(path: String, rootPath: String, onNavigate: (String) -> Unit) {
    val crumbs = remember(path, rootPath) { buildCrumbs(path, rootPath) }
    val listState = rememberLazyListState()
    LaunchedEffect(path) { listState.scrollToItem(crumbs.lastIndex) }
    LazyRow(
        state = listState,
        contentPadding = PaddingValues(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        itemsIndexed(crumbs) { index, crumb ->
            if (index > 0) {
                Icon(
                    Icons.Rounded.ChevronRight, contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp)
                )
            }
            val last = index == crumbs.lastIndex
            Text(
                crumb.label,
                style = MaterialTheme.typography.labelLarge,
                color = if (last) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = !last) { onNavigate(crumb.path) }
                    .padding(horizontal = 6.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Rounded.FolderOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(8.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit, onGoRoot: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(8.dp))
        Text(message, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onRetry) { Text("Réessayer") }
            Button(onClick = onGoRoot) { Text("Stockage interne") }
        }
    }
}
