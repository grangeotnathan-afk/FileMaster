package com.filemaster.app.repository

import com.filemaster.app.database.FavoriteDao
import com.filemaster.app.database.FavoriteEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FavoritesRepository(private val dao: FavoriteDao) {
    /** Chemins favoris, du plus récent au plus ancien. */
    fun observePaths(): Flow<List<String>> = dao.observeAll().map { list -> list.map { it.path } }

    suspend fun add(paths: List<String>) {
        val now = System.currentTimeMillis()
        dao.insertAll(paths.map { FavoriteEntity(it, now) })
    }

    suspend fun remove(paths: List<String>) = dao.deleteAll(paths)

    suspend fun rename(oldPath: String, newPath: String) = dao.rename(oldPath, newPath)
}
