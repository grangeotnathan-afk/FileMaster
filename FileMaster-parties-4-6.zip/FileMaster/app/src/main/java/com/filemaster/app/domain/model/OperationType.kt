package com.filemaster.app.domain.model

enum class OperationType(val label: String) {
    CREATE_FOLDER("Nouveau dossier"),
    RENAME("Renommage"),
    DELETE("Suppression"),
    COPY("Copie"),
    MOVE("Déplacement"),
    DOWNLOAD("Téléchargement"),
    UNKNOWN("Opération");

    companion object {
        fun fromName(name: String): OperationType = values().firstOrNull { it.name == name } ?: UNKNOWN
    }
}

data class OperationRecord(
    val type: OperationType,
    val description: String,
    val success: Boolean,
    val timestamp: Long
)

data class OperationResult(
    val successCount: Int,
    val errors: List<String>
)
