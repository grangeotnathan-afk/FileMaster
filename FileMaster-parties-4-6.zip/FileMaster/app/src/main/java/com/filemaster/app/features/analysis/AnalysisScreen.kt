package com.filemaster.app.features.analysis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ScanStatus
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.features.files.DeleteDialog
import com.filemaster.app.features.permission.PermissionRequiredContent
import com.filemaster.app.features.permission.StoragePermissionState
import com.filemaster.app.utils.FileActions
import com.filemaster.app.utils.formatDate
import com.filemaster.app.utils.formatSize
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalysisScreen(
    permission: StoragePermissionState,
    onOpenCategory: (SmartCategory) -> Unit,
    onOpenFolder: (String) -> Unit,
    viewModel: AnalysisViewModel = viewModel(factory = AnalysisViewModel.Factory)
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var confirmDelete by remember { mutableStateOf(false) }
    val settings = remember { AppSettings() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.messageShown()
        }
    }

    if (!permission.granted) {
        PermissionRequiredContent(onRequest = permission.request)
        return
    }

    val openFile: (FileItem) -> Unit = { FileActions.open(context, File(it.path)) }
    val scan = state.scan

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Analyse du stockage") },
                actions = {
                    if (scan.status == ScanStatus.DONE) {
                        IconButton(onClick = { viewModel.startScan() }) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Relancer l'analyse")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (state.selected.isNotEmpty()) {
                Surface(color = MaterialTheme.colorScheme.primaryContainer) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${state.selected.size} sélectionné(s) • ${formatSize(state.selected.values.sum())}",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        androidx.compose.material3.TextButton(onClick = { viewModel.clearSelection() }) { Text("Vider") }
                        Button(
                            onClick = { confirmDelete = true },
                            enabled = !state.busy,
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) { Text("Supprimer") }
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (scan.status) {
                ScanStatus.IDLE -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Analyser le stockage interne", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "FileMaster parcourt les dossiers auxquels Android l'autorise : répartition par type, plus gros fichiers, " +
                            "doublons, anciens fichiers. Les zones protégées (données d'autres applications, système) ne sont pas analysées.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { viewModel.startScan() }) { Text("Lancer l'analyse") }
                }
                ScanStatus.RUNNING -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(16.dp))
                    Text("Analyse en cours… ${scan.filesFound} fichiers", textAlign = TextAlign.Center)
                }
                ScanStatus.DONE -> {
                    val result = state.result
                    if (result == null) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(AnalysisTab.values().toList(), key = { it.name }) { tab ->
                                FilterChip(selected = state.tab == tab, onClick = { viewModel.setTab(tab) }, label = { Text(tab.label) })
                            }
                        }
                        scan.finishedAt?.let {
                            Text(
                                "Analyse du ${formatDate(it)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                            )
                        }
                        LazyColumn(
                            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 24.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            when (state.tab) {
                                AnalysisTab.OVERVIEW -> overviewTab(
                                    result, scan, state.storage?.used, state.storage?.total, onOpenCategory
                                )
                                AnalysisTab.LARGEST -> selectableFiles(
                                    result.largest, state.selected, settings, viewModel.rootPath,
                                    onToggle = { viewModel.toggle(it) }, onOpen = openFile
                                )
                                AnalysisTab.FOLDERS -> foldersTab(result, viewModel.rootPath, onOpenFolder)
                                AnalysisTab.DUPLICATES -> duplicatesTab(
                                    state, settings, viewModel.rootPath,
                                    onFind = { viewModel.findDuplicates() },
                                    onPreselect = { viewModel.preselectDuplicateCopies() },
                                    onToggle = { viewModel.toggle(it) }, onOpen = openFile
                                )
                                AnalysisTab.OLD -> oldTab(
                                    state, settings, viewModel.rootPath,
                                    onThreshold = { viewModel.setOldThreshold(it) },
                                    onToggle = { viewModel.toggle(it) }, onOpen = openFile
                                )
                                AnalysisTab.JUNK -> selectableFiles(
                                    result.junk.map { it.file }, state.selected, settings, viewModel.rootPath,
                                    reasons = result.junk.associate { it.file.path to it.reason },
                                    onToggle = { viewModel.toggle(it) }, onOpen = openFile
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        DeleteDialog(
            paths = state.selected.keys.toList(),
            onConfirm = { confirmDelete = false; viewModel.deleteSelected() },
            onDismiss = { confirmDelete = false }
        )
    }
}
