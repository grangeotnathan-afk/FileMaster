package com.filemaster.app.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DataUsage
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.filemaster.app.domain.model.FileCategory
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.ItemSize
import com.filemaster.app.domain.model.SmartCategory
import com.filemaster.app.domain.model.StandardFolder
import com.filemaster.app.ui.theme.FolderColor
import com.filemaster.app.ui.theme.StarColor
import com.filemaster.app.utils.elementsLabel
import com.filemaster.app.utils.formatDate
import com.filemaster.app.utils.formatSize
import java.io.File

fun FileCategory.icon(): ImageVector = when (this) {
    FileCategory.IMAGES -> Icons.Rounded.Image
    FileCategory.VIDEOS -> Icons.Rounded.Movie
    FileCategory.AUDIO -> Icons.Rounded.MusicNote
    FileCategory.DOCUMENTS -> Icons.Rounded.Description
    FileCategory.APK -> Icons.Rounded.Android
    FileCategory.ARCHIVES -> Icons.Rounded.Archive
    FileCategory.OTHER -> Icons.Rounded.InsertDriveFile
}

fun FileCategory.color(): Color = when (this) {
    FileCategory.IMAGES -> Color(0xFF4FC3F7)
    FileCategory.VIDEOS -> Color(0xFFFF7A90)
    FileCategory.AUDIO -> Color(0xFFB388FF)
    FileCategory.DOCUMENTS -> Color(0xFF81C784)
    FileCategory.APK -> Color(0xFF69F0AE)
    FileCategory.ARCHIVES -> Color(0xFFFFB74D)
    FileCategory.OTHER -> Color(0xFF90A4AE)
}

fun FileItem.visual(): Pair<ImageVector, Color> =
    if (isDirectory) Icons.Rounded.Folder to FolderColor else category.icon() to category.color()

fun SmartCategory.visual(): Pair<ImageVector, Color> = when (this) {
    SmartCategory.IMAGES -> FileCategory.IMAGES.icon() to FileCategory.IMAGES.color()
    SmartCategory.VIDEOS -> FileCategory.VIDEOS.icon() to FileCategory.VIDEOS.color()
    SmartCategory.AUDIO -> FileCategory.AUDIO.icon() to FileCategory.AUDIO.color()
    SmartCategory.DOCUMENTS -> FileCategory.DOCUMENTS.icon() to FileCategory.DOCUMENTS.color()
    SmartCategory.APK -> FileCategory.APK.icon() to FileCategory.APK.color()
    SmartCategory.ARCHIVES -> FileCategory.ARCHIVES.icon() to FileCategory.ARCHIVES.color()
    SmartCategory.DOWNLOADS -> Icons.Rounded.Download to Color(0xFF4DD0E1)
    SmartCategory.LARGE -> Icons.Rounded.DataUsage to Color(0xFFFF8A65)
    SmartCategory.RECENT -> Icons.Rounded.Schedule to Color(0xFF9FA8DA)
    SmartCategory.FAVORITES -> Icons.Rounded.Star to StarColor
}

fun StandardFolder.visual(): Pair<ImageVector, Color> = when (this) {
    StandardFolder.DOWNLOADS -> Icons.Rounded.Download to Color(0xFF4DD0E1)
    StandardFolder.PICTURES -> Icons.Rounded.Image to Color(0xFF4FC3F7)
    StandardFolder.CAMERA -> Icons.Rounded.CameraAlt to Color(0xFFF48FB1)
    StandardFolder.MUSIC -> Icons.Rounded.MusicNote to Color(0xFFB388FF)
    StandardFolder.MOVIES -> Icons.Rounded.Movie to Color(0xFFFF7A90)
    StandardFolder.DOCUMENTS -> Icons.Rounded.Description to Color(0xFF81C784)
}

fun FileItem.displayName(showExtension: Boolean): String =
    if (showExtension || isDirectory || extension.isEmpty()) name
    else name.substringBeforeLast('.').ifEmpty { name }

fun FileItem.subtitle(): String =
    if (isDirectory) "${childCount?.let { elementsLabel(it) } ?: "—"} • ${formatDate(lastModified)}"
    else "${formatSize(size)} • ${formatDate(lastModified)}"

/** Icône de l'élément ; miniature réelle pour les images et vidéos (repli sur l'icône si illisible). */
@Composable
private fun ItemIcon(item: FileItem, boxSize: Dp, corner: Dp) {
    val (icon, tint) = item.visual()
    val showThumb = !item.isDirectory && (item.category == FileCategory.IMAGES || item.category == FileCategory.VIDEOS)
    Box(
        modifier = Modifier.size(boxSize).clip(RoundedCornerShape(corner)).background(tint.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        val fallback: @Composable () -> Unit = {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(boxSize * 0.55f))
        }
        if (showThumb) {
            val context = LocalContext.current
            val request = remember(item.path) {
                ImageRequest.Builder(context).data(File(item.path)).size(160).crossfade(true).build()
            }
            SubcomposeAsyncImage(
                model = request,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                loading = { fallback() },
                error = { fallback() }
            )
        } else {
            fallback()
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    item: FileItem,
    showExtension: Boolean,
    itemSize: ItemSize,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    favorite: Boolean = false,
    extraLine: String? = null,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val iconBox: Dp = when (itemSize) {
        ItemSize.COMPACT -> 36.dp
        ItemSize.NORMAL -> 44.dp
        ItemSize.LARGE -> 54.dp
    }
    val vPad: Dp = when (itemSize) {
        ItemSize.COMPACT -> 6.dp
        ItemSize.NORMAL -> 9.dp
        ItemSize.LARGE -> 12.dp
    }
    val background = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 10.dp, vertical = vPad),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ItemIcon(item, iconBox, 12.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.displayName(showExtension),
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                item.subtitle(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (extraLine != null) {
                Text(
                    extraLine,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (selected) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = "Sélectionné", tint = MaterialTheme.colorScheme.primary)
        } else if (favorite) {
            Icon(Icons.Rounded.Star, contentDescription = "Favori", tint = StarColor, modifier = Modifier.size(20.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileGridCell(
    item: FileItem,
    showExtension: Boolean,
    itemSize: ItemSize,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    favorite: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val iconBox: Dp = when (itemSize) {
        ItemSize.COMPACT -> 44.dp
        ItemSize.NORMAL -> 56.dp
        ItemSize.LARGE -> 72.dp
    }
    val background = if (selected) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.surfaceVariant

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(10.dp)
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            ItemIcon(item, iconBox, 16.dp)
            Spacer(Modifier.size(6.dp))
            Text(
                item.displayName(showExtension),
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                if (item.isDirectory) item.childCount?.let { elementsLabel(it) } ?: "—" else formatSize(item.size),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        if (selected) {
            Icon(
                Icons.Rounded.CheckCircle, contentDescription = "Sélectionné",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.TopEnd).size(20.dp)
            )
        } else if (favorite) {
            Icon(
                Icons.Rounded.Star, contentDescription = "Favori", tint = StarColor,
                modifier = Modifier.align(Alignment.TopEnd).size(18.dp)
            )
        }
    }
}
