package com.filemaster.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.filemaster.app.domain.model.ThemeMode

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun FileMasterTheme(
    themeMode: ThemeMode,
    primary: Color,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val onPrimary = if (primary.luminance() > 0.5f) Color.Black else Color.White

    val colorScheme = if (dark) {
        val bg = Color(0xFF0E1014)
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = lerp(bg, primary, 0.30f),
            onPrimaryContainer = Color.White,
            background = bg,
            onBackground = Color(0xFFE8EAF0),
            surface = Color(0xFF15181E),
            onSurface = Color(0xFFE8EAF0),
            surfaceVariant = Color(0xFF1F232B),
            onSurfaceVariant = Color(0xFFA9AFBD)
        )
    } else {
        val bg = Color(0xFFF5F6FA)
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = lerp(Color.White, primary, 0.20f),
            onPrimaryContainer = Color(0xFF14161C),
            background = bg,
            onBackground = Color(0xFF14161C),
            surface = Color.White,
            onSurface = Color(0xFF14161C),
            surfaceVariant = Color(0xFFEBEDF4),
            onSurfaceVariant = Color(0xFF5B6070)
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialTheme(colorScheme = colorScheme, shapes = AppShapes, content = content)
}
