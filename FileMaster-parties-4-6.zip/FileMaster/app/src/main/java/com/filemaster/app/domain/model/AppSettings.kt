package com.filemaster.app.domain.model

enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class LayoutMode { LIST, GRID }
enum class ItemSize { COMPACT, NORMAL, LARGE }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val primaryColor: Long = 0xFF6C63FF,
    val layoutMode: LayoutMode = LayoutMode.LIST,
    val itemSize: ItemSize = ItemSize.NORMAL,
    val showExtensions: Boolean = true,
    val showHidden: Boolean = false,
    val sortField: SortField = SortField.NAME,
    val sortAscending: Boolean = true,
    /** Chemin absolu du dossier d'ouverture ; vide = racine du stockage interne. */
    val startFolder: String = "",
    /** Dernier dossier de destination des téléchargements ; vide = Téléchargements. */
    val downloadFolder: String = ""
)
