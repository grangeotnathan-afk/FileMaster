# FileMaster

Gestionnaire de fichiers Android (Kotlin, Jetpack Compose, MVVM, Room, Navigation Compose).
minSdk 26 (Android 8) — targetSdk 34 — 100 % hors ligne, sans compte, sans publicité.

## Ouvrir le projet
1. Android Studio (Koala ou plus récent) → *Open* → dossier `FileMaster`.
2. Laisser la synchronisation Gradle se faire (Gradle 8.7, JDK 17).
3. Lancer sur un téléphone/émulateur, puis accorder l'accès aux fichiers au premier lancement.

## Plan de développement (3 parties par étape)
| # | Partie | État |
|---|--------|------|
| 1 | Structure, Gradle, thème, navigation 5 onglets | fait |
| 2 | Accueil (stockage réel, récents, favoris, activité), permissions, paramètres de base | fait |
| 3 | Explorateur (liste/grille, tri, recherche, filtre, CRUD, copie/déplacement vérifiés, sélection multiple, partage, favoris, propriétés, historique de navigation, fil d'Ariane) | fait |
| 4 | Catégories automatiques + miniatures | fait |
| 5 | Analyse du stockage (gros fichiers, doublons par empreinte, anciens fichiers, graphiques) | fait |
| 6 | Gestionnaire de téléchargements (service, pause/reprise, historique) | fait |
| 7 | Archives ZIP (consulter, extraire, créer) | à faire |
| 8 | Visualiseurs (images, vidéo, audio, PDF, texte) | à faire |
| 9 | Transferts locaux Wi-Fi + QR code + intégrité | à faire |
| 10 | Outils (checksums, comparaison…), paramètres complets, tests, APK | à faire |

## Architecture
```
com.filemaster.app
├── data/          AppContainer (DI manuelle), data/settings (DataStore)
├── database/      Room : favoris, fichiers récents, historique des opérations
├── domain/model/  FileItem, FileCategory, SortOption, AppSettings…
├── repository/    FileRepository, StorageRepository, Favorites/Recent/History
├── features/      home, files, settings, permission, placeholder (1 dossier par fonctionnalité)
├── navigation/    Destination, BottomBar, AppNavHost
├── ui/            theme + composants partagés
├── utils/         formatage, tri, actions système (ouvrir/partager)
└── services/      (réservé aux téléchargements et transferts, parties 6 et 9)
```

## Limites Android (documentées, non contournées)
- Android 11+ : l'accès complet passe par « Accès à tous les fichiers » (réglage système). Android/data et Android/obb restent illisibles.
- Pas de corbeille système : la suppression est définitive (confirmation obligatoire).
- Cartes SD / USB : non gérées pour l'instant (stockage interne uniquement).
- Installation d'APK : non prise en charge pour l'instant.
- Textes en français écrits directement dans le code (extraction vers strings.xml possible plus tard).

## Mises à jour de l'APK sans désinstaller
- `app/filemaster.jks` : clé de signature FIXE (la même à chaque build). Android n'accepte une mise à jour que si la signature est identique.
- En CI, `versionCode` = numéro d'exécution GitHub Actions (`GITHUB_RUN_NUMBER`) : il augmente à chaque build.
- Un APK installé depuis un build local (versionCode 1) peut être mis à jour par un build CI, mais pas l'inverse.
- Le mot de passe de la clé est dans `app/build.gradle.kts` : pratique pour un projet perso, à remplacer par des secrets GitHub si le dépôt devient public.

## Notes techniques parties 4 à 6
- Catégories/analyse : parcours réel du stockage (`ScanRepository`), résultat gardé en mémoire ; les dossiers refusés par Android sont comptés et signalés.
- Doublons : taille identique, puis empreinte SHA-256 partielle, puis empreinte complète.
- Téléchargements : service de premier plan (`dataSync`), HttpURLConnection, reprise via l'en-tête Range si le serveur l'accepte, 3 téléchargements simultanés, reprise après fermeture de l'app. `usesCleartextTraffic` est activé pour permettre http://.
