package com.filemaster.app.data

import android.content.Context
import androidx.room.Room
import com.filemaster.app.data.settings.SettingsRepository
import com.filemaster.app.database.AppDatabase
import com.filemaster.app.repository.FavoritesRepository
import com.filemaster.app.repository.FileRepository
import com.filemaster.app.repository.HistoryRepository
import com.filemaster.app.repository.RecentRepository
import com.filemaster.app.repository.StorageRepository

/** Injection de dépendances manuelle (simple, sans bibliothèque supplémentaire). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: AppDatabase by lazy {
        Room.databaseBuilder(appContext, AppDatabase::class.java, "filemaster.db").build()
    }

    val settingsRepository = SettingsRepository(appContext)
    val storageRepository = StorageRepository()
    val fileRepository = FileRepository()
    val favoritesRepository: FavoritesRepository by lazy { FavoritesRepository(database.favoriteDao()) }
    val recentRepository: RecentRepository by lazy { RecentRepository(database.recentDao()) }
    val historyRepository: HistoryRepository by lazy { HistoryRepository(database.operationDao()) }
}
