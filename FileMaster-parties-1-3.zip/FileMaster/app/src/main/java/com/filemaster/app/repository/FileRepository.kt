package com.filemaster.app.repository

import android.os.Environment
import com.filemaster.app.domain.model.FileCategory
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.OperationResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

/**
 * Accès au système de fichiers via java.io.File (nécessite l'accès aux fichiers accordé par l'utilisateur).
 * Toutes les opérations de copie/déplacement sont vérifiées (taille) avant toute suppression de la source.
 */
class FileRepository {

    fun toItem(file: File): FileItem {
        val isDir = file.isDirectory
        val ext = if (isDir) "" else file.extension.lowercase()
        return FileItem(
            path = file.absolutePath,
            name = file.name.ifEmpty { file.absolutePath },
            isDirectory = isDir,
            size = if (isDir) 0L else file.length(),
            lastModified = file.lastModified(),
            extension = ext,
            category = if (isDir) FileCategory.OTHER else FileCategory.fromExtension(ext),
            childCount = if (isDir) file.list()?.size else null,
            isHidden = file.name.startsWith(".")
        )
    }

    fun itemOrNull(path: String): FileItem? = File(path).takeIf { it.exists() }?.let(::toItem)

    suspend fun list(dir: File, showHidden: Boolean): Result<List<FileItem>> = withContext(Dispatchers.IO) {
        runCatching {
            if (!dir.exists()) throw FileNotFoundException("Ce dossier n'existe plus.")
            if (!dir.isDirectory) throw IOException("Ce n'est pas un dossier.")
            val children = dir.listFiles()
                ?: throw IOException("Accès refusé : Android n'autorise pas la lecture de ce dossier.")
            children.asSequence().map(::toItem).filter { showHidden || !it.isHidden }.toList()
        }
    }

    suspend fun recentFiles(dir: File, limit: Int): List<FileItem> = withContext(Dispatchers.IO) {
        dir.listFiles()
            ?.filter { it.isFile && !it.name.startsWith(".") }
            ?.sortedByDescending { it.lastModified() }
            ?.take(limit)
            ?.map(::toItem)
            ?: emptyList()
    }

    suspend fun search(root: File, query: String, showHidden: Boolean, limit: Int = 300): List<FileItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().lowercase()
            val results = ArrayList<FileItem>()
            val walk = root.walkTopDown().maxDepth(12).onEnter { showHidden || it == root || !it.name.startsWith(".") }
            for (file in walk) {
                ensureActive()
                if (file == root) continue
                if (!showHidden && file.name.startsWith(".")) continue
                if (file.name.lowercase().contains(q)) {
                    results += toItem(file)
                    if (results.size >= limit) break
                }
            }
            results
        }

    suspend fun createFolder(parent: File, name: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val clean = validateName(name)
            val target = File(parent, clean)
            if (target.exists()) throw IOException("« $clean » existe déjà.")
            if (!target.mkdir()) throw IOException("Impossible de créer le dossier (accès refusé ?).")
            target
        }
    }

    suspend fun rename(file: File, newName: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val clean = validateName(newName)
            if (clean == file.name) return@runCatching file
            val target = File(file.parentFile, clean)
            if (target.exists()) throw IOException("« $clean » existe déjà.")
            if (!file.renameTo(target)) throw IOException("Renommage impossible.")
            target
        }
    }

    suspend fun delete(files: List<File>): OperationResult = withContext(Dispatchers.IO) {
        val errors = mutableListOf<String>()
        var ok = 0
        for (file in files) {
            ensureActive()
            when {
                isStorageRoot(file) -> errors += "${file.name} : le stockage interne ne peut pas être supprimé"
                !file.exists() -> errors += "${file.name} : introuvable"
                file.deleteRecursively() -> ok++
                else -> errors += "${file.name} : suppression impossible ou incomplète"
            }
        }
        OperationResult(ok, errors)
    }

    suspend fun copy(files: List<File>, targetDir: File): OperationResult = transfer(files, targetDir, move = false)

    suspend fun move(files: List<File>, targetDir: File): OperationResult = transfer(files, targetDir, move = true)

    /** Calcule la taille totale et le nombre de fichiers (récursif). */
    suspend fun computeSize(file: File): Pair<Long, Int> = withContext(Dispatchers.IO) {
        if (file.isFile) return@withContext file.length() to 1
        var size = 0L
        var count = 0
        for (f in file.walkTopDown()) {
            ensureActive()
            if (f.isFile) {
                size += f.length()
                count++
            }
        }
        size to count
    }

    // ------------------------------------------------------------------ privé

    private suspend fun transfer(files: List<File>, targetDir: File, move: Boolean): OperationResult =
        withContext(Dispatchers.IO) {
            if (!targetDir.isDirectory || !targetDir.canWrite()) {
                return@withContext OperationResult(0, listOf("Le dossier de destination n'est pas accessible en écriture."))
            }
            val errors = mutableListOf<String>()
            var ok = 0
            for (src in files) {
                ensureActive()
                try {
                    if (!src.exists()) throw IOException("introuvable")
                    if (src.isDirectory && isSameOrInside(targetDir, src)) {
                        throw IOException("impossible de placer un dossier dans lui-même")
                    }
                    if (move) moveOne(src, targetDir) else copyOne(src, targetDir)
                    ok++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    errors += "${src.name} : ${e.message ?: "erreur inconnue"}"
                }
            }
            OperationResult(ok, errors)
        }

    private fun copyOne(src: File, targetDir: File) {
        val dst = uniqueTarget(targetDir, src.name, src.isDirectory)
        try {
            copyInto(src, dst)
        } catch (e: Exception) {
            dst.deleteRecursively() // pas de copie partielle laissée derrière
            throw e
        }
    }

    private fun moveOne(src: File, targetDir: File) {
        if (src.parentFile?.canonicalPath == targetDir.canonicalPath) return // déjà au bon endroit
        val dst = uniqueTarget(targetDir, src.name, src.isDirectory)
        if (src.renameTo(dst)) return
        // Autre volume ou renommage refusé : copie vérifiée, puis suppression de la source
        try {
            copyInto(src, dst)
        } catch (e: Exception) {
            dst.deleteRecursively()
            throw e
        }
        if (!src.deleteRecursively()) throw IOException("copié, mais l'original n'a pas pu être supprimé")
    }

    private fun copyInto(src: File, dst: File) {
        if (src.isDirectory) {
            if (!dst.mkdirs()) throw IOException("création du dossier impossible")
            val children = src.listFiles() ?: throw IOException("dossier illisible")
            for (child in children) copyInto(child, File(dst, child.name))
        } else {
            src.inputStream().use { input -> dst.outputStream().use { output -> input.copyTo(output) } }
            if (dst.length() != src.length()) throw IOException("copie incomplète de ${src.name}")
        }
    }

    private fun uniqueTarget(dir: File, name: String, isDir: Boolean): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val (base, ext) = if (!isDir && dot > 0) name.substring(0, dot) to name.substring(dot) else name to ""
        var i = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base ($i)$ext")
            i++
        }
        return candidate
    }

    private fun isSameOrInside(candidate: File, parent: File): Boolean {
        val c = candidate.canonicalPath
        val p = parent.canonicalPath
        return c == p || c.startsWith(p + File.separator)
    }

    @Suppress("DEPRECATION")
    private fun isStorageRoot(file: File): Boolean =
        file.absolutePath == Environment.getExternalStorageDirectory().absolutePath

    private fun validateName(name: String): String {
        val n = name.trim()
        require(n.isNotEmpty()) { "Le nom ne peut pas être vide." }
        require(!n.contains('/') && n != "." && n != "..") { "Nom invalide." }
        return n
    }
}
