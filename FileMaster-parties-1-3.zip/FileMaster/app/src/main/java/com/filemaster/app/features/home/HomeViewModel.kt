package com.filemaster.app.features.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.filemaster.app.FileMasterApp
import com.filemaster.app.data.AppContainer
import com.filemaster.app.domain.model.AppSettings
import com.filemaster.app.domain.model.FileItem
import com.filemaster.app.domain.model.OperationRecord
import com.filemaster.app.domain.model.StandardFolder
import com.filemaster.app.domain.model.StorageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class HomeUiState(
    val loading: Boolean = true,
    val storage: StorageInfo? = null,
    val recentOpened: List<FileItem> = emptyList(),
    val recentDownloads: List<FileItem> = emptyList(),
    val favorites: List<FileItem> = emptyList(),
    val activity: List<OperationRecord> = emptyList()
)

class HomeViewModel(private val c: AppContainer) : ViewModel() {

    private val refreshTick = MutableStateFlow(0)

    val shortcuts: List<Pair<StandardFolder, String>> =
        StandardFolder.values().map { it to c.storageRepository.pathOf(it) }

    val settings: StateFlow<AppSettings> = c.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val uiState: StateFlow<HomeUiState> = combine(
        refreshTick,
        c.favoritesRepository.observePaths(),
        c.recentRepository.observePaths(10),
        c.historyRepository.observeRecent(8)
    ) { _, favoritePaths, recentPaths, operations ->
        withContext(Dispatchers.IO) {
            HomeUiState(
                loading = false,
                storage = c.storageRepository.internalStorage(),
                recentOpened = recentPaths.mapNotNull { c.fileRepository.itemOrNull(it) },
                recentDownloads = c.fileRepository.recentFiles(File(c.storageRepository.pathOf(StandardFolder.DOWNLOADS)), 8),
                favorites = favoritePaths.mapNotNull { c.fileRepository.itemOrNull(it) }.take(10),
                activity = operations
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    /** Relit les valeurs réelles (stockage, dossiers) — appelé à chaque retour sur l'écran. */
    fun refresh() {
        refreshTick.update { it + 1 }
    }

    fun onFileOpened(path: String) {
        viewModelScope.launch { c.recentRepository.record(path) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FileMasterApp
                HomeViewModel(app.container)
            }
        }
    }
}
