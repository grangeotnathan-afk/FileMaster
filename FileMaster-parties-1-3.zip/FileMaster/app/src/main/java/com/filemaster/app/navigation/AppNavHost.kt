package com.filemaster.app.navigation

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.filemaster.app.features.files.FilesScreen
import com.filemaster.app.features.home.HomeScreen
import com.filemaster.app.features.permission.StoragePermissionState
import com.filemaster.app.features.placeholder.PlaceholderScreen
import com.filemaster.app.features.settings.SettingsScreen

@Composable
fun AppNavHost(permission: StoragePermissionState) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            FileMasterBottomBar(current = backStackEntry?.destination) { destination ->
                navController.navigate(destination.route) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Destination.Home.route) {
                HomeScreen(
                    permission = permission,
                    onOpenFolder = { path ->
                        navController.navigate(Destination.Files.create(path = path)) { launchSingleTop = true }
                    },
                    onOpenSearch = {
                        navController.navigate(Destination.Files.create(search = true)) { launchSingleTop = true }
                    }
                )
            }
            composable(
                route = Destination.Files.PATTERN,
                arguments = listOf(
                    navArgument(Destination.Files.ARG_PATH) {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    },
                    navArgument(Destination.Files.ARG_SEARCH) {
                        type = NavType.BoolType
                        defaultValue = false
                    }
                )
            ) {
                FilesScreen(permission = permission)
            }
            composable(Destination.Analysis.route) {
                PlaceholderScreen(
                    title = "Analyse du stockage",
                    part = 5,
                    description = "Répartition par catégories, gros fichiers, doublons par empreinte, anciens fichiers."
                )
            }
            composable(Destination.Transfers.route) {
                PlaceholderScreen(
                    title = "Transferts",
                    part = 9,
                    description = "Téléchargements HTTP/HTTPS (partie 6) et transferts locaux par Wi-Fi avec QR code (partie 9)."
                )
            }
            composable(Destination.Settings.route) {
                SettingsScreen(permission = permission)
            }
        }
    }
}
