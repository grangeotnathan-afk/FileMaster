package com.filemaster.app

import android.app.Application
import com.filemaster.app.data.AppContainer

class FileMasterApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
